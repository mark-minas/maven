package de.unibwm.inf2.pp.util;

import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.SimpleFormatter;

/**
 * {@link SimpleFormatter} variant that prefixes formatted log records with an
 * ANSI color code depending on the log level.
 *
 * <p>
 * The formatter is intended for console output in terminals supporting ANSI
 * escape sequences. Severity levels are mapped to colors as follows:
 * </p>
 * <ul>
 *   <li>{@link Level#SEVERE} and above: red</li>
 *   <li>{@link Level#WARNING} and above: yellow</li>
 *   <li>{@link Level#INFO} and above: green</li>
 *   <li>lower levels: white</li>
 * </ul>
 *
 * <p>
 * The original formatting behavior of {@link SimpleFormatter} is preserved; the
 * color codes are merely wrapped around its output.
 * </p>
 */
public class ColorFormatter extends SimpleFormatter {

    /**
     * ANSI escape prefix.
     */
    private static final String ESC = "\u001B";

    /**
     * ANSI reset sequence.
     */
    private static final String RESET = ESC + "[0m";

    /**
     * ANSI color sequence for severe log output.
     */
    private static final String RED = ESC + "[31m";

    /**
     * ANSI color sequence for warning log output.
     */
    private static final String YELLOW = ESC + "[33m";

    /**
     * ANSI color sequence for informational log output.
     */
    private static final String GREEN = ESC + "[32m";

    /**
     * ANSI color sequence for low-severity log output.
     */
    private static final String WHITE = ESC + "[37m";

    /**
     * Creates a new {@code ColorFormatter}.
     */
    public ColorFormatter() { /* empty */ }

    /**
     * Returns the ANSI color associated with the given log level.
     *
     * @param level log level
     * @return ANSI color sequence used for the given level
     */
    private String getColor(Level level) {
        final var l = level.intValue();
        if (l >= Level.SEVERE.intValue())
            return RED;
        if (l >= Level.WARNING.intValue())
            return YELLOW;
        if (l >= Level.INFO.intValue())
            return GREEN;
        return WHITE;
    }

    /**
     * Formats the given log record and wraps the result in an ANSI color
     * sequence determined by its log level.
     *
     * @param record log record to format
     * @return colored formatted log output
     */
    @Override
    public String format(LogRecord record) {
        return getColor(record.getLevel()) + super.format(record) + RESET;
    }
}