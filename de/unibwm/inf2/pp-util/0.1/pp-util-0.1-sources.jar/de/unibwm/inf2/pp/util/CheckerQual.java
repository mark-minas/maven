//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.util;

import org.checkerframework.checker.initialization.qual.Initialized;
import org.checkerframework.checker.initialization.qual.UnderInitialization;
import org.checkerframework.dataflow.qual.Pure;

/**
 * Checker Framework helper methods for explicit type refinement.
 *
 * <p>
 * This class exists purely to help static analysis. The methods perform no runtime checks and simply
 * return the given reference. They are used to "tell" the Checker Framework that a particular
 * refinement is safe in contexts where inference is insufficient.
 * </p>
 *
 * <p><strong>Safety:</strong> These methods bypass checker guarantees. Use only when you can justify
 * correctness by construction.</p>
 *
 * @see UnderInitialization
 * @see Initialized
 */
public final class CheckerQual {

    private CheckerQual() { /* utility class; not instantiable */ }

    /**
     * Refines an {@code @UnderInitialization} reference to {@code @Initialized}.
     *
     * @param link reference under initialization
     * @param <T>  reference type
     * @return the same reference, treated as {@code @Initialized} by the Checker Framework
     */
    @Pure
    @SuppressWarnings("return")
    public static <T> @Initialized T castInitialized(@UnderInitialization T link) {
        return link;
    }
}