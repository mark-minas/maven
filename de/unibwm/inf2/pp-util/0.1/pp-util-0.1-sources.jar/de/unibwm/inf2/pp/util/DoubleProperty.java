//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.util;

import org.checkerframework.dataflow.qual.SideEffectFree;

import java.util.prefs.Preferences;

/**
 * Preference-backed property for {@code double} values.
 *
 * <p>
 * This class specializes {@link AbstractPreferenceProperty} for values of type
 * {@link Double}. Persistence is realized via
 * {@link Preferences#getDouble(String, double)} and
 * {@link Preferences#putDouble(String, double)}.
 * </p>
 *
 * <p>
 * Equality for change detection is defined by
 * {@link Double#compare(double, double)} in order to obtain precise and
 * well-defined behavior for floating-point values.
 * </p>
 */
public class DoubleProperty extends AbstractPreferenceProperty<Double> {

    /**
     * Creates a new double property with the specified default value.
     *
     * @param preferences preferences node used for storage
     * @param key         preference key
     * @param defaultValue default value used if no persisted value exists
     */
    public DoubleProperty(Preferences preferences, String key, Double defaultValue) {
        super(preferences, key, defaultValue);
    }

    /**
     * Creates a new double property with default value {@code 0.0}.
     *
     * @param preferences preferences node used for storage
     * @param key         preference key
     */
    public DoubleProperty(Preferences preferences, String key) {
        this(preferences, key, 0.0);
    }

    /**
     * Reads a double value from the preferences node.
     *
     * @param preferences  preferences node
     * @param key          preference key
     * @param defaultValue default value used if no persisted value exists
     * @return persisted or default value
     */
    @Override
    protected Double readValue(Preferences preferences, String key, Double defaultValue) {
        return preferences.getDouble(key, defaultValue);
    }

    /**
     * Writes a double value to the preferences node.
     *
     * @param preferences preferences node
     * @param key         preference key
     * @param value       value to persist
     */
    @Override
    protected void writeValue(Preferences preferences, String key, Double value) {
        preferences.putDouble(key, value);
    }

    /**
     * Determines equality of floating-point values for change detection.
     *
     * @param oldValue current cached value
     * @param newValue prospective new value
     * @return {@code true} iff both values compare equal according to
     *         {@link Double#compare(double, double)}
     */
    @Override
    @SideEffectFree
    protected boolean valuesEqual(Double oldValue, Double newValue) {
        return Double.compare(oldValue, newValue) == 0;
    }
}