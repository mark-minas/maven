//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.util;

import java.util.prefs.Preferences;

/**
 * Preference-backed property for {@code boolean} values.
 *
 * <p>
 * This class specializes {@link AbstractPreferenceProperty} for values of type
 * {@link Boolean}. Persistence is realized via
 * {@link Preferences#getBoolean(String, boolean)} and
 * {@link Preferences#putBoolean(String, boolean)}.
 * </p>
 */
public class BooleanProperty extends AbstractPreferenceProperty<Boolean> {

    /**
     * Creates a new boolean property with the specified default value.
     *
     * @param preferences preferences node used for storage
     * @param key         preference key
     * @param defaultValue default value used if no persisted value exists
     */
    public BooleanProperty(Preferences preferences, String key, Boolean defaultValue) {
        super(preferences, key, defaultValue);
    }

    /**
     * Creates a new boolean property with default value {@code false}.
     *
     * @param preferences preferences node used for storage
     * @param key         preference key
     */
    public BooleanProperty(Preferences preferences, String key) {
        this(preferences, key, false);
    }

    /**
     * Reads a boolean value from the preferences node.
     *
     * @param preferences  preferences node
     * @param key          preference key
     * @param defaultValue default value used if no persisted value exists
     * @return persisted or default value
     */
    @Override
    protected Boolean readValue(Preferences preferences, String key, Boolean defaultValue) {
        return preferences.getBoolean(key, defaultValue);
    }

    /**
     * Writes a boolean value to the preferences node.
     *
     * @param preferences preferences node
     * @param key         preference key
     * @param value       value to persist
     */
    @Override
    protected void writeValue(Preferences preferences, String key, Boolean value) {
        preferences.putBoolean(key, value);
    }
}