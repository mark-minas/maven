//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.util;

import org.aeonbits.owner.Tokenizer;

/**
 * Owner {@link Tokenizer} that groups a flat comma-separated list into coordinate pairs.
 *
 * <p>
 * Input values are split on commas and combined into 2-tuples, preserving token text (including empty tokens).
 * For example:
 * </p>
 * <pre>{@code
 * "0,1,2,3,5,7" -> ["0,1", "2,3", "5,7"]
 * }</pre>
 *
 * <p>
 * The tokenizer enforces an even number of tokens; otherwise it throws an {@link IllegalArgumentException}.
 * </p>
 *
 * @see Tokenizer
 */
public class PairTokenizer implements Tokenizer {

    /**
     * Creates a new PairTokenizer.
     */
    public PairTokenizer() { /* empty */ }

    /**
     * Splits the given comma-separated list into 2-element groups.
     *
     * @param values comma-separated values (must contain an even number of tokens)
     * @return array of pair strings in the form {@code "a,b"}
     * @throws IllegalArgumentException if the number of comma-separated tokens is odd
     */
    @Override
    public String[] tokens(String values) {
        var split = values.split(",", -1);
        if (split.length % 2 != 0)
            throw new IllegalArgumentException("Odd number of tokens");

        var result = new String[split.length / 2];
        for (int i = 0; i < split.length; i += 2)
            result[i / 2] = split[i] + "," + split[i + 1];
        return result;
    }
}