//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.util;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * Iterator that presents an arbitrary finite sequence of iterators as one
 * logical iterator.
 *
 * <p>
 * An instance of this class traverses the iterators supplied at construction
 * time in the order in which they are passed to the constructor. All elements
 * of the first iterator are returned first, followed by all elements of the
 * second iterator, and so forth. Hence, this class realizes the concatenation
 * of several iterators into a single sequential view.
 * </p>
 *
 * <p>
 * The implementation is lazy: elements are neither copied nor buffered.
 * Instead, the currently active underlying iterator is queried on demand.
 * Exhausted iterators are skipped automatically.
 * </p>
 *
 * <h2>Semantics</h2>
 * <p>
 * Let {@code i_0, i_1, ..., i_{n-1}} denote the iterators passed to the
 * constructor. Then this iterator yields exactly the elements of
 * {@code i_0}, followed by the elements of {@code i_1}, and so on, until
 * all iterators are exhausted.
 * </p>
 *
 * <ul>
 *   <li>{@link #hasNext()} returns {@code true} iff at least one of the
 *   remaining underlying iterators still provides an element.</li>
 *   <li>{@link #next()} returns the next element of the first not-yet-exhausted
 *   iterator in the remaining sequence.</li>
 *   <li>Empty iterators are permitted and are skipped transparently.</li>
 *   <li>This class does not override {@link #remove()}; consequently, element
 *   removal is unsupported unless explicitly added in a future revision.</li>
 * </ul>
 *
 * <h2>Thread safety</h2>
 * <p>
 * Instances of this class are not thread-safe. Concurrent access must be
 * externally synchronized.
 * </p>
 *
 * @param <T> the element type returned by this iterator
 * @see Iterator
 */
public final class IteratorSequence<T> implements Iterator<T> {

    /**
     * The iterators traversed by this sequence iterator, in traversal order.
     */
    private final Iterator<? extends T>[] iterators;

    /**
     * Index of the currently active iterator.
     *
     * <p>
     * This index is always in the range {@code 0 <= currentIndex <= iterators.length}.
     * If {@code currentIndex == iterators.length}, then all iterators have been
     * exhausted.
     * </p>
     */
    private int currentIndex;

    /**
     * Creates an iterator that traverses the specified iterators sequentially.
     *
     * <p>
     * The iterators are consumed in the exact order in which they are supplied.
     * For example, if the arguments are {@code a}, {@code b}, and {@code c},
     * then the resulting iterator yields all elements of {@code a}, followed by
     * all elements of {@code b}, followed by all elements of {@code c}.
     * </p>
     *
     * <p>
     * The varargs array itself may be empty. In that case, the constructed
     * iterator is empty.
     * </p>
     *
     * @param iterators the iterators to be concatenated; the array reference itself and
     *                  each contained iterator must be non-{@code null}
     * @throws NullPointerException if {@code iterators} is {@code null}, or if any contained iterator
     *                              is {@code null}
     */
    @SafeVarargs
    public IteratorSequence(Iterator<? extends T>... iterators) {
        this.iterators = Objects.requireNonNull(iterators, "iterators").clone();
        for (int i = 0; i < this.iterators.length; i++)
            Objects.requireNonNull(this.iterators[i], "iterators[" + i + "]");
        currentIndex = 0;
    }

    /**
     * Advances {@link #currentIndex} until either a non-exhausted iterator is
     * found or all iterators have been exhausted.
     *
     * <p>
     * After completion of this method, either
     * {@code currentIndex == iterators.length} holds, or
     * {@code iterators[currentIndex].hasNext()} holds.
     * </p>
     */
    private void advanceToNextAvailableIterator() {
        while (currentIndex < iterators.length && !iterators[currentIndex].hasNext())
            currentIndex++;
    }

    /**
     * Indicates whether this iterator still provides another element.
     *
     * <p>
     * This method skips exhausted underlying iterators if necessary.
     * </p>
     *
     * @return {@code true} if at least one further element is available, and
     * {@code false} otherwise
     */
    @Override
    @SuppressWarnings("purity.not.deterministic.not.sideeffectfree.call")
    public boolean hasNext() {
        advanceToNextAvailableIterator();
        return currentIndex < iterators.length;
    }

    /**
     * Returns the next element of the concatenated iterator sequence.
     *
     * <p>
     * The returned element is taken from the first underlying iterator, in
     * traversal order, that is not yet exhausted.
     * </p>
     *
     * @return the next element of the logical concatenation
     * @throws NoSuchElementException if all underlying iterators are exhausted
     */
    @Override
    public T next() {
        if (!hasNext())
            throw new NoSuchElementException("all underlying iterators are exhausted");
        return iterators[currentIndex].next();
    }
}