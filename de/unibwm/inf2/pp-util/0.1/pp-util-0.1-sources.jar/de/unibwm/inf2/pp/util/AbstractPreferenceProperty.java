//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.util;

import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.dataflow.qual.SideEffectFree;

import java.util.Objects;
import java.util.prefs.Preferences;

/**
 * Abstract base class for preference-backed properties with cached access and
 * monotonic change tracking.
 *
 * <p>
 * An instance of this class represents a mutable property value of type
 * {@code T} associated with a fixed key in a given {@link Preferences} node.
 * The property maintains an in-memory cache in order to avoid repeated access
 * to the preferences subsystem.
 * </p>
 *
 * <p>
 * Concrete subclasses define how values of type {@code T} are read from and
 * written to the underlying preferences store. They may also refine the notion
 * of equality used for change detection by overriding
 * {@link #valuesEqual(Object, Object)}.
 * </p>
 *
 * <h2>Persistence model</h2>
 * <p>
 * At construction time, the initial cached value is obtained from the
 * preferences node by calling
 * {@link #readValue(Preferences, String, Object)}. Whenever {@link #set(Object)}
 * changes the cached value, the new value is written back to the preferences
 * node via {@link #writeValue(Preferences, String, Object)}.
 * </p>
 *
 * <h2>Change tracking</h2>
 * <p>
 * The class maintains a monotonically increasing version counter. The counter
 * is incremented exactly when {@link #set(Object)} performs an actual value
 * change. Clients may use {@link #getVersion()} for lightweight change
 * detection.
 * </p>
 *
 * <h2>Thread safety</h2>
 * <p>
 * Instances of this class are not thread-safe. Concurrent access requires
 * external synchronization.
 * </p>
 *
 * @param <T> property value type
 * @see Preferences
 */
public abstract class AbstractPreferenceProperty<T extends @NonNull Object> {

    /**
     * Preferences node used for persistent storage of the property value.
     */
    private final Preferences preferences;

    /**
     * Key under which the property value is stored.
     */
    private final String key;

    /**
     * Cached in-memory value of the property.
     */
    private T value;

    /**
     * Monotonically increasing version counter for change detection.
     */
    private long version;

    /**
     * Creates a new preference-backed property.
     *
     * <p>
     * The initial cached value is obtained by invoking
     * {@link #readValue(Preferences, String, Object)} with the specified
     * preferences node, key, and default value.
     * </p>
     *
     * @param preferences  preferences node used for persistent storage
     * @param key          preference key; must not be {@code null} or blank
     * @param defaultValue default value used if no persisted value exists
     * @throws NullPointerException     if any argument is {@code null}
     * @throws IllegalArgumentException if {@code key} is blank
     */
    @SuppressWarnings("method.invocation")
    protected AbstractPreferenceProperty(Preferences preferences, String key, T defaultValue) {
        this.preferences = Objects.requireNonNull(preferences, "preferences");
        this.key = Objects.requireNonNull(key, "key");
        Objects.requireNonNull(defaultValue, "defaultValue");

        if (key.isBlank())
            throw new IllegalArgumentException("key must not be blank");

        this.value = Objects.requireNonNull(readValue(preferences, key, defaultValue),
                                            "readValue(...) must not return null");
    }

    /**
     * Returns the current cached value.
     *
     * <p>
     * This method is side-effect free and does not access the underlying
     * preferences node.
     * </p>
     *
     * @return current property value
     */
    @SideEffectFree
    public final T get() {
        return value;
    }

    /**
     * Sets the property to the specified value.
     *
     * <p>
     * If the specified value differs from the current cached value according to
     * {@link #valuesEqual(Object, Object)}, the cache is updated, the new value
     * is persisted, and the version counter is incremented. Otherwise, no state
     * change is performed.
     * </p>
     *
     * @param newValue new property value
     * @return {@code true} iff the property value changed
     * @throws NullPointerException if {@code newValue} is {@code null}
     */
    public boolean set(T newValue) {
        Objects.requireNonNull(newValue, "newValue");

        if (valuesEqual(value, newValue))
            return false;

        value = newValue;
        writeValue(preferences, key, newValue);
        version++;
        return true;
    }

    /**
     * Returns the current version counter.
     *
     * @return current version counter
     */
    @SideEffectFree
    public final long getVersion() {
        return version;
    }

    /**
     * Returns the preference key associated with this property.
     *
     * @return preference key
     */
    @SideEffectFree
    public final String getKey() {
        return key;
    }

    /**
     * Returns the preferences node associated with this property.
     *
     * @return underlying preferences node
     */
    @SideEffectFree
    protected final Preferences getPreferences() {
        return preferences;
    }

    /**
     * Determines whether two values are equal for the purpose of change
     * detection.
     *
     * <p>
     * The default implementation delegates to
     * {@link Objects#equals(Object, Object)}.
     * </p>
     *
     * @param oldValue current cached value
     * @param newValue prospective new value
     * @return {@code true} iff both values are considered equal
     */
    @SideEffectFree
    protected boolean valuesEqual(T oldValue, T newValue) {
        return Objects.equals(oldValue, newValue);
    }

    /**
     * Reads a value of type {@code T} from the specified preferences node.
     *
     * @param preferences  preferences node
     * @param key          preference key
     * @param defaultValue default value used if no persisted value exists
     * @return value read from the preferences node; never {@code null}
     */
    protected abstract T readValue(Preferences preferences, String key, T defaultValue);

    /**
     * Writes a value of type {@code T} to the specified preferences node.
     *
     * @param preferences preferences node
     * @param key         preference key
     * @param value       value to be written
     */
    protected abstract void writeValue(Preferences preferences, String key, T value);

    /**
     * Returns a string representation of this property.
     *
     * @return string representation containing key, value, and version
     */
    @Override
    @SuppressWarnings("purity.not.sideeffectfree.call")
    public String toString() {
        return getClass().getSimpleName()
               + "[key=" + key + ", value=" + value + ", version=" + version + "]";
    }
}