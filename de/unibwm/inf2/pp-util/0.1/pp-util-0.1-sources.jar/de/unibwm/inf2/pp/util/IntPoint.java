//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.util;

/**
 * Immutable integer coordinate pair.
 *
 * <p>
 * {@code IntPoint} is a compact value type for grid coordinates, board positions, and similar
 * integer-based 2D geometry.
 * </p>
 *
 * <p>
 * The {@link #valueOf(String)} parser accepts strings of the form {@code "x,y"} and trims whitespace
 * around the components.
 * </p>
 *
 * @param x x-coordinate
 * @param y y-coordinate
 */
public record IntPoint(int x, int y) {
    /**
     * Parses an {@code IntPoint} from a comma-separated string.
     *
     * @param s string in the form {@code "x,y"} (whitespace is allowed around numbers)
     * @return parsed point
     * @throws NumberFormatException          if either component is not a valid integer
     * @throws ArrayIndexOutOfBoundsException if the string does not contain a comma-separated pair
     */
    public static IntPoint valueOf(String s) {
        final String[] split = s.split(",", 2);
        return new IntPoint(Integer.parseInt(split[0].trim()),
                            Integer.parseInt(split[1].trim()));
    }
}