//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

/**
 * General-purpose utility classes used across the project.
 *
 * <p>
 * This package contains reusable infrastructure that is intentionally largely
 * independent of application-specific game logic and rendering concerns.
 * Typical contents include:
 * </p>
 * <ul>
 *   <li>collection and iterator helpers,</li>
 *   <li>small immutable value types,</li>
 *   <li>memoization and preference-backed property abstractions,</li>
 *   <li>notification and logging support, and</li>
 *   <li>auxiliary methods for static-analysis tooling.</li>
 * </ul>
 *
 * <h2>Design principles</h2>
 * <p>
 * The classes in this package are intended to be lightweight, broadly
 * reusable, and minimally coupled. Several utilities are designed to support
 * cross-cutting concerns such as persistence, change tracking, iteration,
 * localization-friendly notification, and static verification.
 * </p>
 *
 * <h2>Examples</h2>
 * <ul>
 *   <li>{@link de.unibwm.inf2.pp.util.AbstractPreferenceProperty} and its concrete subclasses
 *       provide typed wrappers around {@link java.util.prefs.Preferences}.</li>
 *   <li>{@link de.unibwm.inf2.pp.util.CollectionUtil} offers non-destructive collection
 *       construction operations.</li>
 *   <li>{@link de.unibwm.inf2.pp.util.IteratorSequence} and
 *       {@link de.unibwm.inf2.pp.util.RandomPositionIterator} support composite and randomized
 *       iteration.</li>
 *   <li>{@link de.unibwm.inf2.pp.util.IntPoint} provides a compact integer coordinate type.</li>
 *   <li>{@link de.unibwm.inf2.pp.util.Memoizer} supports thread-safe lazy initialization.</li>
 * </ul>
 */
package de.unibwm.inf2.pp.util;