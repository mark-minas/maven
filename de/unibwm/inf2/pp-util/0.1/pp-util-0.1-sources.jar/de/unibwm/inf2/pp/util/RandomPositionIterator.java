//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Random;

/**
 * Iterator that enumerates all grid positions of a {@code width x height} rectangle in random order.
 *
 * <p>
 * Each element corresponds to one coordinate pair {@code (x,y)} with:
 * {@code x in [0, width)} and {@code y in [0, height)}. The order is a uniformly distributed
 * random permutation produced by an in-place Fisher-Yates shuffle strategy.
 * </p>
 *
 * <h2>How elements are produced</h2>
 * <p>
 * The iterator does not materialize the full permutation array. Instead, it keeps a sparse
 * "moved" map representing the swapped positions of the shuffle. Each call to {@link #next()}
 * selects a random index from the remaining range and resolves it to an {@code (x,y)} coordinate,
 * then updates the sparse swap map accordingly.
 * </p>
 *
 * <h2>Complexity</h2>
 * <ul>
 *   <li>Time per element: expected O(1).</li>
 *   <li>Additional memory: O(k) where k is the number of performed swaps stored in {@link #movedMap}.</li>
 * </ul>
 *
 * @param <T> element type produced by {@link Creator#create(int, int)}
 */
public class RandomPositionIterator<T> implements Iterator<T> {
    /**
     * Random source used to select the next index in the Fisher-Yates process.
     */
    private final Random random = new Random();

    /**
     * Height of the rectangle; used to decode a linear index into {@code (x,y)}.
     */
    private final int height;

    /**
     * Sparse map implementing the "virtual array" swaps of the shuffle.
     *
     * <p>Keys are indices; values are the elements currently residing at that index after swaps.</p>
     */
    private final Map<Integer, T> movedMap = new HashMap<>();

    /**
     * Number of positions not yet yielded; also the exclusive upper bound for random index selection.
     */
    private int remaining;

    /**
     * Factory mapping coordinates to values of type {@code T}.
     */
    private final Creator<T> creator;

    /**
     * Factory interface used by {@link RandomPositionIterator} to create elements for a coordinate.
     *
     * @param <T> produced type
     */
    public interface Creator<T> {
        /**
         * Creates an element corresponding to the given grid coordinate.
         *
         * @param x x-coordinate in {@code [0, width)}
         * @param y y-coordinate in {@code [0, height)}
         * @return element representing the position
         */
        T create(int x, int y);
    }

    /**
     * Creates an iterator over a random permutation of all positions in the given rectangle.
     *
     * @param creator value factory for coordinates
     * @param width   rectangle width (number of x positions)
     * @param height  rectangle height (number of y positions)
     */
    public RandomPositionIterator(Creator<T> creator, int width, int height) {
        this.height = height;
        this.remaining = width * height;
        this.creator = Objects.requireNonNull(creator, "creator");
    }

    /**
     * @return {@code true} while there are still unseen positions remaining
     */
    @Override
    public boolean hasNext() {
        return remaining > 0;
    }

    /**
     * Returns the next element in the random permutation.
     *
     * @return next permuted element
     * @throws NoSuchElementException if the permutation is exhausted
     */
    @Override
    public T next() {
        if (hasNext()) {
            final int idx = random.nextInt(remaining--); // note that remaining is decremented
            final T result = getWhere(idx);
            if (idx < remaining)
                movedMap.put(idx, getWhere(remaining));
            movedMap.remove(remaining);
            return result;
        }
        throw new NoSuchElementException();
    }

    /**
     * Resolves a virtual-array index to the element currently stored there.
     *
     * <p>
     * If the index was previously swapped, its value is stored in {@link #movedMap}. Otherwise,
     * the index is decoded to {@code (x,y)} and created on demand via {@link #creator}.
     * </p>
     *
     * @param idx linear index in {@code [0, width*height)}
     * @return element for the resolved coordinate
     */
    private T getWhere(int idx) {
        final T movedWhere = movedMap.get(idx);
        if (movedWhere != null)
            return movedWhere;
        final int x = idx / height;
        final int y = idx % height;
        return creator.create(x, y);
    }
}