//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.util;

import org.checkerframework.checker.i18n.qual.Localized;

import java.util.EventListener;

/**
 * Listener interface for user-facing notifications.
 *
 * <p>
 * {@code NotificationListener} is used to deliver <em>informational</em> and <em>error</em>
 * messages from non-UI components (e.g., controllers, networking, background tasks) to the
 * presentation layer.
 * </p>
 *
 * <h2>Localization contract</h2>
 * <p>
 * Methods that accept message text use the Checker Framework {@link Localized} annotation to
 * document the expectation that the string is already suitable for display to the user.
 * For callers that prefer key-based lookup, {@code info(K, Object...)} and
 * {@code error(K, Object...)} support passing a localization key plus
 * formatting parameters.
 * </p>
 *
 * <h2>Threading and lifecycle</h2>
 * <p>
 * Implementations are typically UI-facing and must assume that notifications can be raised
 * from arbitrary threads. A common strategy is to enqueue UI work onto the application's
 * update loop / UI thread before showing dialogs or updating HUD elements.
 * </p>
 *
 * <p>
 * Error notifications often indicate unrecoverable situations. Implementations may choose
 * to terminate the application after the user acknowledges the error, but this interface
 * intentionally does not prescribe a specific shutdown policy.
 * </p>
 *
 * <h2>Convenience overloads</h2>
 * <p>
 * Default methods exist to convert a {@link Throwable} into localized display text.
 * </p>
 *
 * @param <K> The type of localization keys used for key-based notifications.
 */
public interface NotificationListener<K> extends EventListener {

    /**
     * Displays an informational message.
     *
     * <p>
     * Implementations typically schedule the actual UI update (e.g., opening a dialog or
     * showing a toast) to run in the application's update loop.
     * </p>
     *
     * @param text localized message text to display
     */
    void info(String text);

    /**
     * Displays an informational message identified by a localization key.
     *
     * <p>
     * The {@code key} is expected to be resolved against the application's resource bundle,
     * with {@code params} used for message formatting/substitution as defined by the
     * implementation.
     * </p>
     *
     * @param key    resource-bundle key identifying the message
     * @param params optional formatting parameters for the message
     */
    void info(K key, Object... params);

    /**
     * Displays an error message.
     *
     * <p>
     * Implementations typically schedule the UI update (e.g., opening an error dialog) to
     * run in the application's update loop. Depending on the application policy, an error
     * may be followed by shutdown after user acknowledgement.
     * </p>
     *
     * @param text localized message text to display
     */
    void error(String text);

    /**
     * Displays an error message identified by a localization key.
     *
     * <p>
     * The {@code key} is expected to be resolved against the application's resource bundle,
     * with {@code params} used for message formatting/substitution as defined by the
     * implementation.
     * </p>
     *
     * @param key    resource-bundle key identifying the message
     * @param params optional formatting parameters for the message
     */
    void error(K key, Object... params);

    /**
     * Convenience overload that converts the given {@link Throwable} into localized display
     * text and reports it as info.
     *
     * @param throwable the cause to display as info (typically {@link Throwable#getLocalizedMessage()}
     *                  plus an optional cause chain
     */
    default void info(Throwable throwable) {
        info(getText(throwable));
    }

    /**
     * Convenience overload that converts the given {@link Throwable} into localized display
     * text and reports it as an error.
     *
     * @param throwable the cause to display as error (typically {@link Throwable#getLocalizedMessage()}
     *                  plus an optional cause chain
     */
    default void error(Throwable throwable) {
        error(getText(throwable));
    }

    /**
     * Returns a non-null message for {@code throwable}, optionally including its cause's message.
     *
     * @param throwable error to format
     * @return non-null, displayable message text (potentially multi-line)
     */
    private String getText(Throwable throwable) {
        String nonNullMsg = getMessageText(throwable);
        if (throwable.getCause() == null)
            return nonNullMsg;
        return nonNullMsg + "\n" + getMessageText(throwable.getCause());
    }

    /**
     * Returns a non-null message for {@code throwable}.
     *
     * @param throwable error to format
     * @return {@link Throwable#getLocalizedMessage()} if non-null; otherwise {@link Throwable#toString()}
     */
    private String getMessageText(Throwable throwable) {
        final String msg = throwable.getLocalizedMessage();
        return msg != null ? msg : throwable.toString();
    }
}