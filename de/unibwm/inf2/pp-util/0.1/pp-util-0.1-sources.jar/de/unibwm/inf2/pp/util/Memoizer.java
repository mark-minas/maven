//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.util;

import java.util.Objects;
import java.util.function.Supplier;

/**
 * Thread-safe, one-shot memoizing {@link Supplier}.
 *
 * <p>
 * {@code Memoizer} computes its value at most once via the provided {@link Supplier}, caches the result, and
 * returns the cached value on subsequent {@link #get()} calls. The implementation uses
 * double-checked locking with a {@code volatile} guard flag.
 * </p>
 *
 * <h2>Exception behavior</h2>
 * <p>
 * If the {@link Supplier} throws an exception, the value is <em>not</em> cached and a later call to
 * {@link #get()} will retry the computation.
 * </p>
 *
 * <h2>Threading</h2>
 * <p>
 * The cached value is published safely after {@code saved} is set to {@code true}. The provided {@link Supplier}
 * should ensure that its {@link Supplier#get()} is side-effect-free or otherwise safe to run more than once
 * in the presence of failures.
 * </p>
 *
 * @param <T> supplied value type
 */
public class Memoizer<T> implements Supplier<T> {
    private T value;
    private volatile boolean saved;
    private final Supplier<T> supplier;

    /**
     * Creates a new Memoizer.
     *
     * @param supplier the supplier computing the memoized value.
     */
    @SuppressWarnings("initialization.fields.uninitialized")
    public Memoizer(Supplier<T> supplier) {
        this.supplier = Objects.requireNonNull(supplier, "supplier");
    }

    /**
     * Returns the cached value, computing it on first use.
     *
     * @return memoized value
     */
    @Override
    public T get() {
        if (saved) return value;
        synchronized (this) {
            if (!saved) {
                @SuppressWarnings("UnnecessaryLocalVariable") final T computed = supplier.get();
                // only change value if supplier.get() didn't throw an exception
                value = computed;
                saved = true;
            }
        }
        return value;
    }
}