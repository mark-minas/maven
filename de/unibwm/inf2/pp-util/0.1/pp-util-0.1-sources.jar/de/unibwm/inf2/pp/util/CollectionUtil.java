//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.util;

import org.checkerframework.dataflow.qual.SideEffectFree;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Utility class providing factory-like operations for constructing new
 * collections from existing collections.
 *
 * <p>
 * All methods of this class are static and return newly allocated result
 * collections. The input collections are never modified. Thus, the operations
 * implemented here are non-destructive with respect to their arguments.
 * </p>
 *
 * <p>
 * The methods preserve the semantic properties of the concrete result type used:
 * unions are returned as instances of {@link Set} and therefore eliminate
 * duplicates, whereas concatenation and append/prepend operations are returned
 * as instances of {@link List} and therefore preserve element multiplicity and
 * order.
 * </p>
 *
 * <p>
 * Where possible, result collections are created with an initial capacity that
 * is intended to reduce internal resizing during population.
 * </p>
 *
 * <h2>Thread safety</h2>
 * <p>
 * This class is stateless. However, no synchronization is performed on the
 * provided input collections. Consequently, correct behavior requires that the
 * supplied collections are not concurrently modified during method execution.
 * </p>
 */
public final class CollectionUtil {

    /**
     * Heuristic factor used when sizing result sets.
     *
     * <p>
     * Since duplicate elimination may reduce the final number of stored
     * elements, this factor merely provides extra capacity in order to reduce
     * rehashing. It does not affect the semantic behavior of the methods.
     * </p>
     */
    private static final int SET_CAPACITY_FACTOR = 2;

    /**
     * Prevents instantiation of this utility class.
     */
    private CollectionUtil() { /* do not instantiate */ }

    /**
     * Returns a newly allocated set containing the union of the two specified
     * collections.
     *
     * <p>
     * The resulting set contains every element that occurs in {@code c1}, in
     * {@code c2}, or in both. As the result type is a set, duplicate elements
     * are represented only once according to the equality semantics of the set
     * implementation.
     * </p>
     *
     * <p>
     * Neither input collection is modified.
     * </p>
     *
     * @param c1  the first input collection; must not be {@code null}
     * @param c2  the second input collection; must not be {@code null}
     * @param <T> the common element type
     * @return a new set containing all distinct elements of {@code c1} and
     * {@code c2}
     * @throws NullPointerException if {@code c1} or {@code c2} is {@code null}
     */
    @SideEffectFree
    @SuppressWarnings("purity.not.sideeffectfree.call")
    public static <T> Set<T> union(Collection<? extends T> c1, Collection<? extends T> c2) {
        Objects.requireNonNull(c1, "c1");
        Objects.requireNonNull(c2, "c2");

        final Set<T> result = new HashSet<>(SET_CAPACITY_FACTOR * (c1.size() + c2.size()));
        result.addAll(c1);
        result.addAll(c2);
        return result;
    }

    /**
     * Returns a newly allocated set containing all elements of the specified
     * collection together with the given element.
     *
     * <p>
     * If {@code element} is already contained in {@code collection}, the result
     * still contains it only once, because the returned collection is a set.
     * </p>
     *
     * <p>
     * The input collection is not modified.
     * </p>
     *
     * @param collection the base collection; must not be {@code null}
     * @param element    the additional element to be included
     * @param <T>        the element type
     * @return a new set containing all distinct elements of {@code collection}
     * and {@code element}
     * @throws NullPointerException if {@code collection} is {@code null}
     */
    @SideEffectFree
    @SuppressWarnings("purity.not.sideeffectfree.call")
    public static <T> Set<T> union(Collection<? extends T> collection, T element) {
        Objects.requireNonNull(collection, "collection");

        final Set<T> result = new HashSet<>(SET_CAPACITY_FACTOR * (collection.size() + 1));
        result.addAll(collection);
        result.add(element);
        return result;
    }

    /**
     * Returns a newly allocated list containing the elements of {@code list1}
     * followed by the elements of {@code list2}.
     *
     * <p>
     * The relative order of the elements of each input list is preserved.
     * Element multiplicities are preserved as well.
     * </p>
     *
     * <p>
     * Neither input list is modified.
     * </p>
     *
     * @param list1 the first list; its elements appear first in the result;
     *              must not be {@code null}
     * @param list2 the second list; its elements are appended after those of
     *              {@code list1}; must not be {@code null}
     * @param <T>   the common element type
     * @return a new list containing the concatenation of {@code list1} and
     * {@code list2}
     * @throws NullPointerException if {@code list1} or {@code list2} is {@code null}
     */
    @SideEffectFree
    @SuppressWarnings("purity.not.sideeffectfree.call")
    public static <T> List<T> concat(List<? extends T> list1, List<? extends T> list2) {
        Objects.requireNonNull(list1, "list1");
        Objects.requireNonNull(list2, "list2");

        final List<T> result = new ArrayList<>(list1.size() + list2.size());
        result.addAll(list1);
        result.addAll(list2);
        return result;
    }

    /**
     * Returns a newly allocated list containing the elements of three or more
     * lists concatenated in the order in which they are provided.
     *
     * <p>
     * The resulting list contains first all elements of {@code list1}, followed by
     * all elements of {@code list2}, followed by all elements of {@code list3},
     * and finally the elements of any additional lists supplied in {@code moreLists}.
     * The relative order of elements within each input list is preserved.
     * </p>
     *
     * <p>
     * Element multiplicities are preserved, and none of the input lists is
     * modified. The result list is allocated with an initial capacity equal to the
     * sum of the sizes of all provided lists in order to minimize internal
     * resizing during construction.
     * </p>
     *
     * <p>
     * At least three lists must be provided. If fewer lists are needed, the
     * overload {@link #concat(List, List)} should be used instead.
     * </p>
     *
     * @param list1     the first list; must not be {@code null}
     * @param list2     the second list; must not be {@code null}
     * @param list3     the third list; must not be {@code null}
     * @param moreLists additional lists whose elements are appended in the given order;
     *                  the array itself and each contained list must not be {@code null}
     * @param <T>       the common element type
     * @return a newly allocated list containing the concatenation of all provided
     * lists in the given order
     * @throws NullPointerException if any list reference is {@code null}
     */
    @SideEffectFree
    @SuppressWarnings("purity.not.sideeffectfree.call")
    @SafeVarargs
    public static <T> List<T> concat(
            List<? extends T> list1,
            List<? extends T> list2,
            List<? extends T> list3,
            List<? extends T>... moreLists) {

        Objects.requireNonNull(list1, "list1");
        Objects.requireNonNull(list2, "list2");
        Objects.requireNonNull(list3, "list3");
        Objects.requireNonNull(moreLists, "moreLists");

        int size = list1.size() + list2.size() + list3.size();

        for (int i = 0; i < moreLists.length; i++) {
            Objects.requireNonNull(moreLists[i], "moreLists[" + i + "]");
            size += moreLists[i].size();
        }

        final List<T> result = new ArrayList<>(size);

        result.addAll(list1);
        result.addAll(list2);
        result.addAll(list3);

        for (List<? extends T> list : moreLists)
            result.addAll(list);

        return result;
    }

    /**
     * Returns a newly allocated list containing all elements of {@code list}
     * followed by {@code element}.
     *
     * <p>
     * The order of the original list is preserved.
     * </p>
     *
     * @param list    the base list; must not be {@code null}
     * @param element the element to append
     * @param <T>     the element type
     * @return a new list containing all elements of {@code list}, followed by
     * {@code element}
     * @throws NullPointerException if {@code list} is {@code null}
     */
    @SideEffectFree
    @SuppressWarnings("purity.not.sideeffectfree.call")
    public static <T> List<T> append(List<? extends T> list, T element) {
        Objects.requireNonNull(list, "list");

        final List<T> result = new ArrayList<>(list.size() + 1);
        result.addAll(list);
        result.add(element);
        return result;
    }

    /**
     * Returns a newly allocated list containing {@code element} followed by all
     * elements of {@code list}.
     *
     * <p>
     * The order of the original list is preserved after the prepended element.
     * </p>
     *
     * @param element the element to prepend
     * @param list    the base list; must not be {@code null}
     * @param <T>     the element type
     * @return a new list containing {@code element} followed by all elements of
     * {@code list}
     * @throws NullPointerException if {@code list} is {@code null}
     */
    @SideEffectFree
    @SuppressWarnings("purity.not.sideeffectfree.call")
    public static <T> List<T> prepend(T element, List<? extends T> list) {
        Objects.requireNonNull(list, "list");

        final List<T> result = new ArrayList<>(list.size() + 1);
        result.add(element);
        result.addAll(list);
        return result;
    }
}