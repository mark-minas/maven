//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

/**
 * Annotation types for compile-time generation of delegate and state-pattern
 * infrastructure.
 *
 * <h2>Overview</h2>
 * This package contains annotations used by an annotation processor to
 * generate delegation scaffolding, state base classes, and augmented
 * interfaces. The generated code typically follows composition-based
 * delegation patterns or classic state-pattern architectures.
 *
 * <h2>Processing Model</h2>
 * Most annotations in this package use {@link java.lang.annotation.RetentionPolicy#SOURCE}
 * and are intended exclusively for compile-time processing.
 * No runtime reflection support is required (except where explicitly stated).
 *
 * <h2>Typical Use Cases</h2>
 * <ul>
 *   <li>Generating state-based delegate implementations</li>
 *   <li>Creating abstract base state classes</li>
 *   <li>Augmenting existing interfaces with additional parameters</li>
 *   <li>Enforcing structural delegation constraints</li>
 * </ul>
 * <p>
 * The annotations are designed to reduce boilerplate while maintaining
 * explicit interface-driven design.
 */
package de.unibwm.inf2.annotation.delegate;