//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.delegate;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Triggers generation of a base state implementation for an interface.
 * <p>
 * The generated class provides default behavior for all interface methods,
 * typically throwing exceptions or logging invocations, and can be used
 * as a starting point for concrete state implementations.
 * <p>
 * This annotation is processed at compile time.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.SOURCE)
public @interface GenerateBaseState {

    /**
     * Specifies the simple name of the generated base class.
     * <p>
     * Default: {@code Base<InterfaceName>}
     *
     * @return the generated class name
     */
    String className() default "";

    /**
     * Specifies the package of the generated class.
     * <p>
     * Default: same package as the interface.
     *
     * @return the target package
     */
    String targetPackage() default "";

    /**
     * If {@code true}, generated void methods log and throw
     * {@link UnsupportedOperationException}, even if a default method exists.
     *
     * @return whether void methods should throw an exception
     */
    boolean throwOnVoid() default false;

    /**
     * Determines whether the generated class should be {@code public}.
     *
     * @return {@code true} if the generated class is public
     */
    boolean isPublic() default true;

    /**
     * Name of an optional generated entry method.
     * <p>
     * Default: no entry method is generated.
     *
     * @return the name of the entry method, or empty if none
     */
    String entryMethod() default "";
}