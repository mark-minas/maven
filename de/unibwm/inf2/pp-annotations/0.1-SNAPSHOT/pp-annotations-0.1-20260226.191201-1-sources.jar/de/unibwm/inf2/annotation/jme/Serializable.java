//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a Java record for SpiderMonkey serializer code generation.
 * <p>
 * If {@code id >= 0}, generated registration uses
 * {@code Serializer.registerClassForId(id, ...)}.
 * Otherwise, it uses {@code Serializer.registerClass(recordClass, serializerInstance)}.
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.TYPE)
public @interface Serializable {

    /**
     * Optional fixed SpiderMonkey class identifier for deterministic
     * registration across client and server.
     * <p>
     * Use {@code -1} to indicate that no fixed identifier is used.
     *
     * @return SpiderMonkey class id, or -1 if none
     */
    short id() default -1;
}