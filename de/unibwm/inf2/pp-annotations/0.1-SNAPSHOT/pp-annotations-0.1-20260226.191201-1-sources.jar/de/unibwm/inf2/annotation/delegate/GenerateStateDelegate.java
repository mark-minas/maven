//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.delegate;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Triggers generation of a state-based delegate implementation for an interface.
 * <p>
 * The generated delegate forwards method calls to a state object obtained
 * either via an abstract accessor or a {@code Supplier}, depending on the
 * selected {@link DelegatorKind}.
 * <p>
 * This annotation is processed at compile time.
 */
@Target(ElementType.TYPE)          // apply to interfaces
@Retention(RetentionPolicy.SOURCE) // compile-time only
public @interface GenerateStateDelegate {

    /**
     * Specifies the simple name of the generated class.
     * <p>
     * Default: {@code <InterfaceName>Delegate}
     *
     * @return the simple name of the generated delegate class
     */
    String className() default "";

    /**
     * Specifies the package of the generated class.
     * <p>
     * Default: same package as the annotated interface.
     *
     * @return the target package for the generated class
     */
    String targetPackage() default "";

    /**
     * Specifies the name of the {@code Supplier} field used to retrieve the state.
     *
     * @return the field name used for the state supplier
     */
    String supplierField() default "stateSupplier";

    /**
     * Determines whether delegator methods are generated for default methods
     * declared in the interface.
     *
     * @return {@code true} if default methods should be delegated
     */
    boolean delegateDefaultMethods() default true;

    /**
     * Determines whether the generated class should be declared {@code public}.
     *
     * @return {@code true} if the generated class is public
     */
    boolean isPublic() default true;

    /**
     * Controls which kind of delegate implementation is generated.
     * <p>
     * Default: {@link DelegatorKind#STATE_SUPPLIER}
     *
     * @return the delegator generation strategy
     */
    DelegatorKind kind() default DelegatorKind.STATE_SUPPLIER;

    /**
     * Defines the available delegate generation strategies.
     */
    enum DelegatorKind {

        /**
         * Generates an abstract base class that declares an abstract
         * {@code getState()} method to be implemented by subclasses.
         */
        ABSTRACT_BASE_CLASS,

        /**
         * Generates a concrete class that retrieves its state
         * via a {@code Supplier}.
         */
        STATE_SUPPLIER
    }
}