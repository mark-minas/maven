//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.delegate;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Triggers generation of an augmented delegate interface and injector class.
 * <p>
 * The generated interface extends an existing interface and appends
 * an additional parameter to its methods. A corresponding injector
 * class is generated to supply the additional parameter.
 * <p>
 * This annotation is processed at compile time.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.SOURCE)
public @interface GenerateAugmentedDelegate {

    /**
     * Fully qualified name of the interface whose methods shall be augmented.
     *
     * @return the FQCN of the interface to augment
     */
    String augment();

    /**
     * Type of the appended parameter (must be a valid fully qualified type name).
     *
     * @return the type of the additional parameter
     */
    String paramType();

    /**
     * Name of the appended parameter (must be a valid Java identifier).
     *
     * @return the parameter name to use in generated methods
     */
    String paramName();

    /**
     * Simple name of the generated augmented interface.
     * <p>
     * Default: {@code <Interface>WithParam}
     *
     * @return the generated interface name
     */
    String generatedInterface() default "";

    /**
     * Simple name of the generated injector class.
     * <p>
     * Default: {@code <Interface>Injector}
     *
     * @return the generated class name
     */
    String generatedClass() default "";

    /**
     * Target package for generated types.
     * <p>
     * Default: same package as the augmented interface.
     *
     * @return the target package for generated sources
     */
    String targetPackage() default "";

    /**
     * Determines whether delegators for default methods are generated.
     *
     * @return {@code true} if default methods should be delegated
     */
    boolean delegateDefaultMethods() default true;
}