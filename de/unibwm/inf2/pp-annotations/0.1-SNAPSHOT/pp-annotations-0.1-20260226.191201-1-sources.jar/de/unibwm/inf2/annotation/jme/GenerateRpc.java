//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Triggers generation of RPC support classes for JMonkeyEngine networking.
 * <p>
 * The annotation processor generates message and service infrastructure
 * for the specified RPC interfaces.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.SOURCE)
public @interface GenerateRpc {

    /**
     * Target package in which all generated sources are placed
     * (typically within the network module).
     *
     * @return the target package
     */
    String targetPackage() default "";

    /**
     * Optional prefix added to generated class names.
     *
     * @return the class name prefix
     */
    String prefix() default "";

    /**
     * Default reliability flag for generated messages.
     * Corresponds to {@code AbstractMessage.setReliable(boolean)}.
     *
     * @return {@code true} if messages are reliable by default
     */
    boolean reliableByDefault() default true;

    /**
     * Fully qualified class names of RPC interfaces
     * for which code should be generated.
     *
     * @return array of RPC interface FQCNs
     */
    String[] value();
}