//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Triggers generation of SpiderMonkey serializers for multiple types.
 * <p>
 * Each referenced type is configured via a {@link Ref} entry.
 * An optional aggregator class may be generated to register all serializers.
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.TYPE)
public @interface GenerateSerializers {

    /**
     * Serializer generation configurations for referenced types.
     *
     * @return array of type references
     */
    Ref[] value();

    /**
     * Configuration entry describing a single serializer generation target.
     */
    @Retention(RetentionPolicy.SOURCE)
    @Target({})
    @interface Ref {

        /**
         * Fully qualified class name of the target type.
         *
         * @return target type FQCN
         */
        String fqn();

        /**
         * Optional SpiderMonkey id; {@code -1} indicates none.
         *
         * @return SpiderMonkey id
         */
        short id() default -1;

        /**
         * Package in which the serializer should be generated.
         * <p>
         * If empty, the target type's package is used.
         *
         * @return generation package
         */
        String genPackage() default "";

        /**
         * Encoding mode for enum types.
         *
         * @return enum encoding mode
         */
        EnumMode enumMode() default EnumMode.NAME;

        /**
         * Construction strategy override for POJOs.
         *
         * @return construction strategy
         */
        Construction construction() default Construction.AUTO;

        /**
         * Optional fully qualified factory method
         * in the form {@code "com.pkg.Factory#create"}.
         *
         * @return factory method reference
         */
        String factoryMethod() default "";

        /**
         * Determines whether nullable markers should be written
         * for reference fields in generated POJO serializers.
         *
         * @return {@code true} if nullable markers are emitted
         */
        boolean writeNullableMarker() default true;
    }

    /**
     * Defines how enum values are encoded in the generated serializer.
     * <p>
     * The selected mode determines the wire representation written to and
     * read from the SpiderMonkey stream.
     *
     * <h2>Encoding Strategies</h2>
     * <ul>
     *   <li>{@link #ORDINAL} – Encodes the enum using its ordinal value
     *       ({@code Enum.ordinal()}). This is compact but fragile with respect
     *       to enum constant reordering.</li>
     *   <li>{@link #NAME} – Encodes the enum using its constant name
     *       ({@code Enum.name()}). This is more stable across versions but
     *       slightly larger on the wire.</li>
     * </ul>
     *
     * <h2>Compatibility Considerations</h2>
     * Using {@link #ORDINAL} requires strict consistency of enum declaration
     * order across client and server versions. {@link #NAME} is generally
     * safer for distributed systems where independent deployment may occur.
     */
    enum EnumMode {
        /**
         * Serializes the enum using its ordinal index.
         * <p>
         * Compact representation but sensitive to declaration order changes.
         */
        ORDINAL,

        /**
         * Serializes the enum using its constant name.
         * <p>
         * More robust against reordering but requires string transmission.
         */
        NAME
    }

    /**
     * Defines how instances of POJO types are constructed during deserialization.
     * <p>
     * This setting influences how the generated serializer instantiates and
     * populates target objects.
     *
     * <h2>Construction Strategies</h2>
     * <ul>
     *   <li>{@link #AUTO} – Processor selects a suitable strategy automatically
     *       based on available constructors and setters.</li>
     *   <li>{@link #SETTERS} – Uses a no-argument constructor followed by
     *       setter invocation for each field.</li>
     *   <li>{@link #CONSTRUCTOR} – Uses an all-arguments constructor
     *       matching the serialized field order.</li>
     *   <li>{@link #FACTORY} – Uses a specified static factory method
     *       (see {@code factoryMethod}).</li>
     * </ul>
     *
     * <h2>Design Implications</h2>
     * The chosen strategy must be compatible with the target class design.
     * For immutable types, {@link #CONSTRUCTOR} or {@link #FACTORY} are
     * typically appropriate. Mutable JavaBeans-style classes commonly
     * use {@link #SETTERS}.
     */
    enum Construction {

        /**
         * Automatically determines the most appropriate construction strategy.
         */
        AUTO,

        /**
         * Uses a no-argument constructor and setter methods.
         */
        SETTERS,

        /**
         * Uses a matching constructor with parameters for all serialized fields.
         */
        CONSTRUCTOR,

        /**
         * Uses a static factory method for instance creation.
         */
        FACTORY
    }

    /**
     * Package in which the serializer aggregator class is generated.
     *
     * @return aggregator package
     */
    String aggregatorPackage() default "";

    /**
     * Name of the generated serializer registry class.
     *
     * @return aggregator class name
     */
    String aggregatorClassName() default "SerializerRegistry";
}