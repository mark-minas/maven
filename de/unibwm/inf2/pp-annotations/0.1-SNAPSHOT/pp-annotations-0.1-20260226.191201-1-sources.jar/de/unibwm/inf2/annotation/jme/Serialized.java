//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a method or accessor for inclusion in generated
 * SpiderMonkey serialization code.
 * <p>
 * This annotation is retained at runtime.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Serialized {

    /**
     * Preferred wire order index.
     * <p>
     * If {@code -1}, declaration order may be used (processor may issue a warning).
     *
     * @return serialization order index
     */
    int index() default -1;

    /**
     * Indicates whether the serialized value may be {@code null}
     * (only relevant for reference types).
     *
     * @return {@code true} if null values are permitted
     */
    boolean nullable() default true;

    /**
     * Optional converter class used for custom serialization.
     * <p>
     * Not implemented in this example.
     *
     * @return converter class, or {@link Void} if none
     */
    Class<?> converter() default Void.class;
}