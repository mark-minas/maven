//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

/**
 * Annotation types for code generation related to JMonkeyEngine (JME)
 * networking and SpiderMonkey serialization.
 *
 * <h2>Overview</h2>
 * This package provides annotations that trigger generation of:
 * <ul>
 *   <li>RPC (Remote Procedure Call) infrastructure</li>
 *   <li>SpiderMonkey-compatible serializers</li>
 *   <li>Message registration utilities</li>
 * </ul>
 * <p>
 * The goal is to eliminate repetitive networking and serialization boilerplate
 * while ensuring deterministic client/server compatibility.
 *
 * <h2>Processing Model</h2>
 * Most annotations are retained in {@link java.lang.annotation.RetentionPolicy#SOURCE}
 * and processed at compile time by an annotation processor.
 * Selected annotations (e.g., {@code @Serialized}) may use
 * {@link java.lang.annotation.RetentionPolicy#RUNTIME} if required
 * for runtime metadata inspection.
 *
 * <h2>Design Goals</h2>
 * <ul>
 *   <li>Deterministic message registration across distributed systems</li>
 *   <li>Explicit wire-format control</li>
 *   <li>Configurable enum encoding and object construction strategies</li>
 *   <li>Clear separation between model, networking, and generated infrastructure</li>
 * </ul>
 * <p>
 * These annotations are particularly suited for multiplayer game
 * architectures built on top of JMonkeyEngine.
 */
package de.unibwm.inf2.annotation.jme;