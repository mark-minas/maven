//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme.network.serializing;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a getter-like method for inclusion in generated SpiderMonkey
 * serialization code.
 *
 * <p>
 * This annotation is primarily intended for POJO-style serializer generation.
 * It identifies the methods whose values form the serialized state of the
 * object and supplies additional metadata such as wire order and nullability.
 * </p>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Serialized {

    /**
     * Returns the preferred serialization order index.
     *
     * <p>
     * Smaller indices are serialized earlier. A value of {@code -1} indicates
     * that no explicit index is given.
     * </p>
     *
     * @return serialization-order index, or {@code -1} if unspecified
     */
    int index() default -1;

    /**
     * Indicates whether the serialized value may be {@code null}.
     *
     * <p>
     * This setting is relevant only for reference types.
     * </p>
     *
     * @return {@code true} if {@code null} is permitted
     */
    boolean nullable() default true;

    /**
     * Returns an optional converter type for custom serialization behavior.
     *
     * <p>
     * If no converter is specified, {@link Void} is used as a sentinel value.
     * </p>
     *
     * @return converter class, or {@link Void} if none is specified
     */
    Class<?> converter() default Void.class;
}