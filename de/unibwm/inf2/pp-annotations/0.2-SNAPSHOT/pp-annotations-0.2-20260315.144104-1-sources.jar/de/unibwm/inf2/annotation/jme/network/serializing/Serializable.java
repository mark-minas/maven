//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme.network.serializing;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a type for generation of a dedicated SpiderMonkey serializer.
 *
 * <p>
 * The annotation is intended for records, enums, and supported POJO-style
 * classes. The generated serializer can optionally be registered with a fixed
 * SpiderMonkey class identifier in order to guarantee deterministic
 * client/server compatibility.
 * </p>
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.TYPE)
public @interface Serializable {

    /**
     * Returns the optional fixed SpiderMonkey class identifier.
     *
     * <p>
     * A non-negative value requests registration with a fixed id. The value
     * {@code -1} indicates that no fixed identifier is specified.
     * </p>
     *
     * @return SpiderMonkey class identifier, or {@code -1} if none is specified
     */
    short id() default -1;
}