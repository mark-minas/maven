//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

/**
 * Annotation types for compile-time generation of delegation- and state-oriented
 * scaffolding.
 *
 * <p>
 * This package defines the public annotation model for generating auxiliary
 * types that support interface-based delegation and state-pattern
 * implementations. Typical generated artifacts include:
 * </p>
 * <ul>
 *   <li>delegates forwarding calls to a current state object,</li>
 *   <li>abstract base classes for concrete state implementations, and</li>
 *   <li>augmented delegate variants that inject an additional fixed argument
 *       into delegated calls.</li>
 * </ul>
 *
 * <h2>Processing model</h2>
 * <p>
 * Most annotations in this package are retained only in
 * {@link java.lang.annotation.RetentionPolicy#SOURCE} and are intended
 * exclusively for annotation processing. The generated code reduces repetitive
 * boilerplate while preserving explicit, interface-driven design.
 * </p>
 *
 * <h2>Runtime-visible annotations</h2>
 * <p>
 * {@link de.unibwm.inf2.annotation.delegate.AlwaysAllowed} is retained at
 * runtime because it expresses a semantic property of interface methods that
 * may also be relevant beyond source generation.
 * </p>
 */
package de.unibwm.inf2.annotation.delegate;