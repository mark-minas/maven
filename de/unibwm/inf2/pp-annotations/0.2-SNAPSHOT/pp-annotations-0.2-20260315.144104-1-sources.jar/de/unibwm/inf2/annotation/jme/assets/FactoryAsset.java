//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme.assets;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Declares a manifest asset whose creation is delegated to a default method of
 * the same asset-manifest interface.
 *
 * <p>
 * In contrast to path-based asset annotations, {@code FactoryAsset} does not
 * describe direct loading through the jME asset system. Instead, the generated
 * implementation invokes a designated default method of the manifest interface
 * to construct the asset. This is intended for assets whose initialization
 * requires logic that cannot be expressed by the predefined asset annotations.
 * </p>
 *
 * <p>
 * The referenced creator method must be a default interface method with a
 * processor-compatible signature. The generated implementation invokes that
 * method via {@code Interface.super}.
 * </p>
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.METHOD)
public @interface FactoryAsset {

    /**
     * Returns the sharing policy applied by the generated accessor.
     *
     * @return sharing policy
     */
    Sharing sharing() default Sharing.NONE;

    /**
     * Returns the name of the default interface method used to create the asset.
     *
     * @return creator-method name
     */
    String creator();

    /**
     * Returns the clone method used for {@link Sharing#PROTOTYPE}.
     *
     * <p>
     * This value is relevant only if {@link #sharing()} equals
     * {@link Sharing#PROTOTYPE}. The referenced method is expected to be a
     * compatible default method in the same manifest interface.
     * </p>
     *
     * @return clone-method name, or the empty string if no explicit clone method
     *         is specified
     */
    String cloneMethod() default "";
}