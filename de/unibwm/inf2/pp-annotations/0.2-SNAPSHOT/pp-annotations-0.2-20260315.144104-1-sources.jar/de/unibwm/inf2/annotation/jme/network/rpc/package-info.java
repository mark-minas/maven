//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

/**
 * Annotation types for compile-time generation of JMonkeyEngine SpiderMonkey
 * RPC infrastructure.
 *
 * <p>
 * This package provides annotations that describe remote-procedure interfaces
 * from which auxiliary network classes are generated, such as message types,
 * remote proxies, dispatchers, and registration utilities.
 * </p>
 *
 * <p>
 * The annotations in this package are intended for source-level processing and
 * support deterministic generation of networking boilerplate for distributed
 * jME applications.
 * </p>
 */
package de.unibwm.inf2.annotation.jme.network.rpc;