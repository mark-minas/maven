//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme.assets;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Declares an asset-manifest interface for compile-time implementation
 * generation.
 *
 * <p>
 * An interface annotated with {@code AssetInterface} defines a typed,
 * declarative specification of runtime assets for a jMonkeyEngine-based
 * application. Each manifest method denotes one logical asset and is annotated
 * with exactly one concrete asset annotation, for example {@link ModelAsset},
 * {@link TextureAsset}, {@link MaterialAsset}, {@link AudioAsset},
 * {@link FontAsset}, {@link PictureAsset}, or {@link FactoryAsset}.
 * </p>
 *
 * <h2>Processing model</h2>
 * <p>
 * During annotation processing, a concrete implementation class is generated
 * for the annotated interface. For each asset method, the generated class
 * contains code for loading, constructing, configuring, and exposing the asset
 * according to the declaration in the manifest. Depending on the selected
 * {@link Sharing} policy, the generated accessor may return a fresh instance, a
 * lazily initialized singleton, or a clone of a cached prototype.
 * </p>
 *
 * <h2>Structural requirements</h2>
 * <ul>
 *   <li>The annotated program element must be an interface.</li>
 *   <li>Asset methods must not declare parameters.</li>
 *   <li>Asset methods must return a non-{@code void} reference type compatible
 *       with the respective asset annotation.</li>
 * </ul>
 *
 * <h2>Preloading</h2>
 * <p>
 * The generated implementation additionally provides a method returning preload
 * tasks for the assets declared in the manifest. These tasks can be used to
 * load assets eagerly during application startup.
 * </p>
 *
 * @see Sharing
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.TYPE)
public @interface AssetInterface {

    /**
     * Returns the base name of the generated implementation class.
     *
     * <p>
     * If this value is blank, the generator derives the class name from the
     * manifest interface name. The suffix {@code Impl} is appended to the
     * effective base name.
     * </p>
     *
     * @return base name of the generated implementation class, or the empty
     *         string for the default naming convention
     */
    String implementingClass() default "";

    /**
     * Returns the name of the generated preload-task method.
     *
     * <p>
     * If this value is blank, the generated method is named
     * {@code preloadTasks}.
     * </p>
     *
     * @return preload-task method name, or the empty string for the default name
     */
    String preloadTasks() default "";
}