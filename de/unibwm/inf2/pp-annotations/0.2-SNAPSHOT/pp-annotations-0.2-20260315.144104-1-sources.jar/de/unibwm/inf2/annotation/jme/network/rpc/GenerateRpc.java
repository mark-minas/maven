//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme.network.rpc;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Triggers generation of SpiderMonkey RPC support classes for a set of
 * interfaces.
 *
 * <p>
 * For each configured interface, the corresponding processor generates message
 * classes, a remote proxy, a dispatcher, and registration support. The
 * generated code is intended for use with JMonkeyEngine networking and the
 * SpiderMonkey message-serialization mechanism.
 * </p>
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.SOURCE)
public @interface GenerateRpc {

    /**
     * Returns the target package in which the generated sources are placed.
     *
     * <p>
     * If this value is blank, a processor-defined default package is used.
     * </p>
     *
     * @return target package
     */
    String targetPackage() default "";

    /**
     * Returns an optional prefix added to generated type names.
     *
     * @return class-name prefix, or the empty string if no prefix is used
     */
    String prefix() default "";

    /**
     * Indicates whether generated messages are reliable by default.
     *
     * <p>
     * This corresponds to the reliability flag of SpiderMonkey message types.
     * </p>
     *
     * @return {@code true} if generated messages are reliable by default
     */
    boolean reliableByDefault() default true;

    /**
     * Returns the fully qualified names of the RPC interfaces for which support
     * code shall be generated.
     *
     * @return array of RPC-interface names
     */
    String[] value();
}