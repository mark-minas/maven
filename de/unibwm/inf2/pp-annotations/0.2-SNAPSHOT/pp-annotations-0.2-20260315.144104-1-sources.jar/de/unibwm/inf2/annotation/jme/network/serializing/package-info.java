//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

/**
 * Annotation types for compile-time generation of SpiderMonkey serializers and
 * serializer-registration support.
 *
 * <p>
 * This package defines the public annotation model for generating serializer
 * implementations for records, enums, and selected POJO-style classes. The
 * generated code is intended for use with JMonkeyEngine SpiderMonkey
 * serialization and supports deterministic registration across communicating
 * systems.
 * </p>
 *
 * <p>
 * The package includes annotations for marking individual serializable types,
 * configuring batch generation, and declaring the wire-relevant members of
 * POJO-style classes.
 * </p>
 */
package de.unibwm.inf2.annotation.jme.network.serializing;