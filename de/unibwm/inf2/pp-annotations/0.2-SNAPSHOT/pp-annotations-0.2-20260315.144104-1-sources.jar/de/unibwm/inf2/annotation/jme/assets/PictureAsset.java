//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme.assets;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Declares a picture asset in an {@link AssetInterface} manifest.
 *
 * <p>
 * The annotated method must return {@code com.jme3.ui.Picture} or a subtype.
 * The generated implementation constructs a {@code Picture}, loads the declared
 * image, and applies the configuration parameters specified by this annotation.
 * </p>
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.METHOD)
public @interface PictureAsset {
    /**
     * Returns the asset path interpreted by the jME {@code AssetManager}.
     *
     * @return path of the image resource
     */
    String path();

    /**
     * Returns the logical name assigned to the picture.
     *
     * <p>
     * If this value is blank, the manifest method name is used.
     * </p>
     *
     * @return logical picture name, or the empty string for the default name
     */
    String name() default "";

    /**
     * Returns the sharing policy applied by the generated accessor.
     *
     * @return sharing policy
     */
    Sharing sharing() default Sharing.NONE;

    /**
     * Returns the clone method used for {@link Sharing#PROTOTYPE}.
     *
     * <p>
     * This value is relevant only if {@link #sharing()} equals
     * {@link Sharing#PROTOTYPE}. If no explicit method is specified, the
     * processor expects a suitable public {@code clone()} method on the return
     * type.
     * </p>
     *
     * @return clone-method name, or the empty string if default cloning is to
     *         be used
     */
    String cloneMethod() default "";

    /**
     * Indicates whether the image shall be flipped vertically.
     *
     * @return {@code true} if the image is flipped along the y-axis
     */
    boolean flipY() default false;

    /**
     * Indicates whether alpha information shall be used when setting the image.
     *
     * @return {@code true} if alpha handling is enabled
     */
    boolean useAlpha() default false;
}