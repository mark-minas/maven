//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme.assets;

import com.jme3.audio.AudioData;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Declares an audio-node asset in an {@link AssetInterface} manifest.
 *
 * <p>
 * The annotated method must return {@code com.jme3.audio.AudioNode} or a
 * subtype. The generated implementation loads the referenced audio resource and
 * configures the resulting node according to the annotation parameters.
 * </p>
 *
 * <p>
 * Besides the asset path, this annotation controls audio-specific properties
 * such as data type, looping behavior, positional playback, and initial
 * volume. Reuse behavior is determined by {@link #sharing()}.
 * </p>
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.METHOD)
public @interface AudioAsset {
    /**
     * Returns the asset path interpreted by the jME {@code AssetManager}.
     *
     * @return path of the audio resource
     */
    String path();

    /**
     * Returns the logical name assigned to the generated
     * {@code com.jme3.audio.AudioNode}.
     *
     * <p>
     * If this value is blank, the manifest method name is used.
     * </p>
     *
     * @return logical node name, or the empty string for the default name
     */
    String name() default "";

    /**
     * Returns the sharing policy applied by the generated accessor.
     *
     * @return sharing policy
     */
    Sharing sharing() default Sharing.NONE;

    /**
     * Returns the clone method used for {@link Sharing#PROTOTYPE}.
     *
     * <p>
     * This value is relevant only if {@link #sharing()} equals
     * {@link Sharing#PROTOTYPE}. If no explicit method is specified, the
     * processor expects a suitable public {@code clone()} method on the return
     * type.
     * </p>
     *
     * @return clone-method name, or the empty string if default cloning is to
     *         be used
     */
    String cloneMethod() default "";

    /**
     * Returns the jME audio data type used when constructing the audio node.
     *
     * @return audio data type
     */
    AudioData.DataType type() default AudioData.DataType.Buffer;

    /**
     * Indicates whether the audio node shall loop during playback.
     *
     * @return {@code true} if looping is enabled
     */
    boolean loop() default false;

    /**
     * Indicates whether the audio node shall be positional.
     *
     * @return {@code true} if positional playback is enabled
     */
    boolean positional() default false;

    /**
     * Returns the initial playback volume.
     *
     * @return initial volume
     */
    float volume() default 1.0f;
}