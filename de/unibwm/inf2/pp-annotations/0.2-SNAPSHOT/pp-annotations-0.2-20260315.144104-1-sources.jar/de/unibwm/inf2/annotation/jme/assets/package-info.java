//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

/**
 * Declarative asset-manifest annotations for jMonkeyEngine applications.
 *
 * <p>
 * This package defines the public annotation model for compile-time generation
 * of typed asset-access implementations. An application declares an
 * {@link de.unibwm.inf2.annotation.jme.assets.AssetInterface asset manifest
 * interface}; each method of that interface denotes one logical asset and is
 * annotated with a concrete asset descriptor such as
 * {@link de.unibwm.inf2.annotation.jme.assets.ModelAsset},
 * {@link de.unibwm.inf2.annotation.jme.assets.TextureAsset},
 * {@link de.unibwm.inf2.annotation.jme.assets.MaterialAsset},
 * {@link de.unibwm.inf2.annotation.jme.assets.AudioAsset},
 * {@link de.unibwm.inf2.annotation.jme.assets.FontAsset},
 * {@link de.unibwm.inf2.annotation.jme.assets.PictureAsset}, or
 * {@link de.unibwm.inf2.annotation.jme.assets.FactoryAsset}.
 * </p>
 *
 * <h2>Purpose</h2>
 * <p>
 * The annotations in this package provide a strongly typed and declarative
 * description of runtime assets. The corresponding code generator validates
 * these declarations at compile time and generates implementation classes that
 * perform loading, custom construction, optional caching, and preload-task
 * creation.
 * </p>
 *
 * <h2>Reuse semantics</h2>
 * <p>
 * Asset reuse is governed by
 * {@link de.unibwm.inf2.annotation.jme.assets.Sharing}. Depending on the
 * selected policy, generated accessors either create fresh instances, return a
 * cached singleton, or return clones of a cached prototype.
 * </p>
 */
package de.unibwm.inf2.annotation.jme.assets;