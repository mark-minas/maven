//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme.assets;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Declares a bitmap-font asset in an {@link AssetInterface} manifest.
 *
 * <p>
 * The annotated method must return {@code com.jme3.font.BitmapFont} or a
 * subtype. The generated implementation loads the font from the declared asset
 * path and exposes it according to the selected {@link Sharing} policy.
 * </p>
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.METHOD)
public @interface FontAsset {
    /**
     * Returns the asset path interpreted by the jME {@code AssetManager}.
     *
     * @return path of the font resource
     */
    String path();

    /**
     * Returns the sharing policy applied by the generated accessor.
     *
     * @return sharing policy
     */
    Sharing sharing() default Sharing.NONE;

    /**
     * Returns the clone method used for {@link Sharing#PROTOTYPE}.
     *
     * <p>
     * This value is relevant only if {@link #sharing()} equals
     * {@link Sharing#PROTOTYPE}. If no explicit method is specified, the
     * processor expects a suitable public {@code clone()} method on the return
     * type.
     * </p>
     *
     * @return clone-method name, or the empty string if default cloning is to
     *         be used
     */
    String cloneMethod() default "";
}