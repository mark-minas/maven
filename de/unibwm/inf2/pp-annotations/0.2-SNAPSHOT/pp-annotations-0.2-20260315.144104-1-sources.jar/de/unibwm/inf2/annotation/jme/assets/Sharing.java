//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme.assets;

/**
 * Specifies the reuse policy applied by generated asset accessors.
 *
 * <p>
 * The selected sharing mode determines whether the generated implementation
 * creates a fresh instance for each access, reuses a cached singleton, or
 * returns clones of a cached prototype.
 * </p>
 */
public enum Sharing {
    /**
     * Indicates that no caching is performed.
     *
     * <p>
     * Each accessor call creates a fresh asset instance. During preloading, the
     * asset is created once, but the result is not retained.
     * </p>
     */
    NONE,

    /**
     * Indicates singleton-style reuse.
     *
     * <p>
     * A single asset instance is created lazily and returned by all subsequent
     * accessor calls. During preloading, this cached instance is initialized.
     * </p>
     */
    SINGLETON,

    /**
     * Indicates prototype-based reuse.
     *
     * <p>
     * A prototype instance is created lazily and cached. Each accessor call
     * returns a clone of that prototype. During preloading, only the prototype
     * itself is initialized.
     * </p>
     *
     * <p>
     * Cloning is performed either via an explicitly configured clone method or,
     * if none is specified, via a suitable public no-argument
     * {@code clone()} method on the return type.
     * </p>
     */
    PROTOTYPE,
}