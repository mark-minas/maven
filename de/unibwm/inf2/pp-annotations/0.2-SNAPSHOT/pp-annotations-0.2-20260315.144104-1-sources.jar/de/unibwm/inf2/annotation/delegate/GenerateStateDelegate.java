//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.delegate;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Triggers generation of a delegate implementation for a state-oriented
 * interface.
 *
 * <p>
 * The generated type implements the annotated interface and forwards eligible
 * method calls to a state instance. Depending on the selected
 * {@link DelegatorKind}, the state is obtained either from a generated
 * {@code Supplier}-based field or via an abstract accessor method to be
 * implemented by subclasses.
 * </p>
 *
 * <p>
 * This annotation is intended for interfaces whose operational semantics depend
 * on a current state object while the public API remains stable.
 * </p>
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.SOURCE)
public @interface GenerateStateDelegate {

    /**
     * Returns the simple name of the generated delegate class.
     *
     * <p>
     * If this value is blank, the default name
     * {@code <InterfaceName>Delegate} is used.
     * </p>
     *
     * @return generated class name, or the empty string for the default naming
     *         convention
     */
    String className() default "";

    /**
     * Returns the package in which the generated class is placed.
     *
     * <p>
     * If this value is blank, the package of the annotated interface is used.
     * </p>
     *
     * @return target package, or the empty string for the default package choice
     */
    String targetPackage() default "";

    /**
     * Returns the name of the generated {@code Supplier} field used for state
     * retrieval.
     *
     * <p>
     * This setting is relevant only for
     * {@link DelegatorKind#STATE_SUPPLIER}.
     * </p>
     *
     * @return supplier-field name
     */
    String supplierField() default "stateSupplier";

    /**
     * Indicates whether default interface methods shall also be delegated.
     *
     * @return {@code true} if delegating methods are generated for default
     *         methods
     */
    boolean delegateDefaultMethods() default true;

    /**
     * Indicates whether the generated class shall be declared {@code public}.
     *
     * @return {@code true} if the generated class is public
     */
    boolean isPublic() default true;

    /**
     * Returns the delegate generation strategy.
     *
     * @return delegate kind
     */
    DelegatorKind kind() default DelegatorKind.STATE_SUPPLIER;

    /**
     * Enumeration of supported delegate generation strategies.
     */
    enum DelegatorKind {

        /**
         * Generates an abstract base class that defines delegation logic but
         * leaves state retrieval to subclasses via an abstract
         * {@code getState()} method.
         */
        ABSTRACT_BASE_CLASS,

        /**
         * Generates a concrete delegate class whose state is obtained from a
         * {@code Supplier}.
         */
        STATE_SUPPLIER
    }
}