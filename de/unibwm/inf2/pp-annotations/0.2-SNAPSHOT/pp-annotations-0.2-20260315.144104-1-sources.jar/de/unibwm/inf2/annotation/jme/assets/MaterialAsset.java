//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme.assets;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Declares a material asset in an {@link AssetInterface} manifest.
 *
 * <p>
 * The annotated method must return {@code com.jme3.material.Material} or a
 * subtype. The generated implementation creates the material from the declared
 * path, assigns the configured logical name, and exposes it according to the
 * selected {@link Sharing} policy.
 * </p>
 *
 * <p>
 * Material construction can be controlled explicitly via {@link #mode()}, or
 * determined automatically from the path suffix.
 * </p>
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.METHOD)
public @interface MaterialAsset {
    /**
     * Returns the asset path interpreted by the jME {@code AssetManager}.
     *
     * @return path of the material resource or material definition
     */
    String path();

    /**
     * Returns the logical name assigned to the material.
     *
     * <p>
     * If this value is blank, the manifest method name is used.
     * </p>
     *
     * @return logical material name, or the empty string for the default name
     */
    String name() default "";

    /**
     * Returns the sharing policy applied by the generated accessor.
     *
     * @return sharing policy
     */
    Sharing sharing() default Sharing.NONE;

    /**
     * Returns the clone method used for {@link Sharing#PROTOTYPE}.
     *
     * <p>
     * This value is relevant only if {@link #sharing()} equals
     * {@link Sharing#PROTOTYPE}. If no explicit method is specified, the
     * processor expects a suitable public {@code clone()} method on the return
     * type.
     * </p>
     *
     * @return clone-method name, or the empty string if default cloning is to
     *         be used
     */
    String cloneMethod() default "";

    /**
     * Returns the strategy used to construct the material from the declared
     * path.
     *
     * @return material-construction mode
     */
    MaterialLoadMode mode() default MaterialLoadMode.AUTO;

    /**
     * Specifies how a material is obtained from the declared path.
     */
    enum MaterialLoadMode {
        /**
         * Determines the construction mode automatically from the file suffix.
         *
         * <p>
         * A path ending in {@code .j3m} is treated as a material instance and
         * loaded via {@code AssetManager.loadMaterial}. Other paths are treated
         * as material-definition paths and passed to the {@code Material}
         * constructor.
         * </p>
         */
        AUTO,

        /**
         * Loads the material via {@code AssetManager.loadMaterial(path)}.
         */
        FROM_J3M,

        /**
         * Constructs the material via {@code new Material(assetManager, path)}.
         */
        FROM_MATDEF
    }
}