//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.delegate;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a method as semantically permitted in all generated state contexts.
 *
 * <p>
 * This annotation is used by delegate- and state-generation tooling to denote
 * methods that shall not be treated as state-restricted operations. In
 * particular, generated base-state classes may omit denial or fallback logic
 * for such methods, and generated state-oriented APIs may expose them as
 * universally available operations.
 * </p>
 *
 * <p>
 * The annotation is retained at runtime so that the information remains
 * available for reflective analysis or additional framework-level processing.
 * </p>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface AlwaysAllowed {}