//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.delegate;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Triggers generation of an augmented delegate pair for an existing interface.
 *
 * <p>
 * The processor generates:
 * </p>
 * <ul>
 *   <li>an augmented interface whose methods correspond to those of a target
 *       interface but accept one additional trailing parameter, and</li>
 *   <li>a concrete injector class implementing the original interface by
 *       delegating to the augmented interface with a fixed injected argument.</li>
 * </ul>
 *
 * <p>
 * This mechanism is useful when an existing API shall be adapted to an
 * implementation that systematically requires additional contextual
 * information.
 * </p>
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.SOURCE)
public @interface GenerateAugmentedDelegate {

    /**
     * Returns the fully qualified name of the interface whose methods are to be
     * augmented.
     *
     * @return fully qualified target interface name
     */
    String augment();

    /**
     * Returns the type of the appended parameter.
     *
     * <p>
     * The value must denote a type name resolvable during annotation
     * processing.
     * </p>
     *
     * @return appended-parameter type
     */
    String paramType();

    /**
     * Returns the name of the appended parameter.
     *
     * <p>
     * The value must be a valid Java identifier.
     * </p>
     *
     * @return appended-parameter name
     */
    String paramName();

    /**
     * Returns the simple name of the generated augmented interface.
     *
     * <p>
     * If this value is blank, the default name
     * {@code <InterfaceName>WithParam} is used.
     * </p>
     *
     * @return generated interface name, or the empty string for the default
     *         naming convention
     */
    String generatedInterface() default "";

    /**
     * Returns the simple name of the generated injector class.
     *
     * <p>
     * If this value is blank, the default name
     * {@code <InterfaceName>Injector} is used.
     * </p>
     *
     * @return generated injector-class name, or the empty string for the
     *         default naming convention
     */
    String generatedClass() default "";

    /**
     * Returns the target package for the generated types.
     *
     * <p>
     * If this value is blank, the package of the annotated element is used.
     * </p>
     *
     * @return target package, or the empty string for the default package choice
     */
    String targetPackage() default "";

    /**
     * Indicates whether default methods of the augmented interface shall also be
     * represented in the generated types.
     *
     * @return {@code true} if default methods are included
     */
    boolean delegateDefaultMethods() default true;
}