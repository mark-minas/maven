//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.delegate;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Triggers generation of an abstract base class for a state-oriented interface.
 *
 * <p>
 * The generated class implements the annotated interface and provides default
 * behavior for state-restricted operations. Depending on configuration and the
 * shape of the interface methods, generated implementations may log denied
 * operations, delegate to interface default methods, or throw an
 * {@link UnsupportedOperationException}.
 * </p>
 *
 * <p>
 * This annotation is intended to support state-pattern implementations in which
 * concrete state classes inherit common denial and fallback behavior from a
 * generated superclass.
 * </p>
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.SOURCE)
public @interface GenerateBaseState {

    /**
     * Returns the simple name of the generated base class.
     *
     * <p>
     * If this value is blank, the default name
     * {@code Base<InterfaceName>} is used.
     * </p>
     *
     * @return generated class name, or the empty string for the default naming
     *         convention
     */
    String className() default "";

    /**
     * Returns the package in which the generated base class is placed.
     *
     * <p>
     * If this value is blank, the package of the annotated interface is used.
     * </p>
     *
     * @return target package, or the empty string for the default package choice
     */
    String targetPackage() default "";

    /**
     * Indicates whether generated {@code void} methods shall throw an
     * {@link UnsupportedOperationException} after logging.
     *
     * @return {@code true} if generated {@code void} methods shall throw
     */
    boolean throwOnVoid() default false;

    /**
     * Indicates whether the generated class shall be declared {@code public}.
     *
     * @return {@code true} if the generated class is public
     */
    boolean isPublic() default true;

    /**
     * Returns the name of an optional protected entry method generated in the
     * base class.
     *
     * <p>
     * If this value is blank, no such method is generated.
     * </p>
     *
     * @return entry-method name, or the empty string if no entry method shall be
     *         generated
     */
    String entryMethod() default "";
}