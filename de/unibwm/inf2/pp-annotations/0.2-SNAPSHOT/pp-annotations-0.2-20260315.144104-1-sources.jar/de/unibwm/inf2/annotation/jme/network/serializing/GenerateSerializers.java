//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.annotation.jme.network.serializing;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Triggers batch generation of SpiderMonkey serializers for multiple types.
 *
 * <p>
 * Each referenced target type is described by a {@link Ref} entry. Optionally,
 * an additional aggregator class is generated that registers all produced
 * serializers.
 * </p>
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.TYPE)
public @interface GenerateSerializers {

    /**
     * Returns the serializer-generation configurations for the referenced types.
     *
     * @return referenced target configurations
     */
    Ref[] value();

    /**
     * Configuration entry describing one serializer-generation target.
     */
    @Retention(RetentionPolicy.SOURCE)
    @Target({})
    @interface Ref {

        /**
         * Returns the fully qualified name of the target type.
         *
         * @return target-type name
         */
        String fqn();

        /**
         * Returns the optional fixed SpiderMonkey identifier.
         *
         * <p>
         * A value of {@code -1} indicates that no fixed identifier is used.
         * </p>
         *
         * @return SpiderMonkey identifier, or {@code -1} if none is specified
         */
        short id() default -1;

        /**
         * Returns the package in which the serializer is generated.
         *
         * <p>
         * If this value is empty, the package of the target type is used.
         * </p>
         *
         * @return generation package, or the empty string for the default package
         */
        String genPackage() default "";

        /**
         * Returns the enum encoding mode.
         *
         * @return enum encoding mode
         */
        EnumMode enumMode() default EnumMode.NAME;

        /**
         * Returns the construction strategy for POJO-style types.
         *
         * @return construction strategy
         */
        Construction construction() default Construction.AUTO;

        /**
         * Returns an optional static factory method reference.
         *
         * <p>
         * The value is expected in the form {@code "com.pkg.Factory#create"}.
         * </p>
         *
         * @return factory-method reference, or the empty string if none is used
         */
        String factoryMethod() default "";

        /**
         * Indicates whether nullable markers shall be emitted for reference
         * values in generated POJO serializers.
         *
         * @return {@code true} if nullable markers are written
         */
        boolean writeNullableMarker() default true;
    }

    /**
     * Enumeration of supported enum-serialization strategies.
     */
    enum EnumMode {
        /**
         * Serializes enum values using their ordinal indices.
         *
         * <p>
         * This representation is compact but sensitive to declaration-order
         * changes.
         * </p>
         */
        ORDINAL,

        /**
         * Serializes enum values using their declared constant names.
         *
         * <p>
         * This representation is more robust against reordering but requires
         * string transmission.
         * </p>
         */
        NAME
    }

    /**
     * Enumeration of supported construction strategies for POJO-style
     * deserialization.
     */
    enum Construction {

        /**
         * Lets the processor determine a suitable construction strategy
         * automatically.
         */
        AUTO,

        /**
         * Uses a no-argument constructor followed by setter invocation.
         */
        SETTERS,

        /**
         * Uses a constructor whose parameters match the serialized members.
         */
        CONSTRUCTOR,

        /**
         * Uses a designated static factory method.
         */
        FACTORY
    }

    /**
     * Returns the package in which the optional serializer-aggregator class is
     * generated.
     *
     * @return aggregator package
     */
    String aggregatorPackage() default "";

    /**
     * Returns the name of the generated serializer-aggregator class.
     *
     * @return aggregator class name
     */
    String aggregatorClassName() default "SerializerRegistry";
}