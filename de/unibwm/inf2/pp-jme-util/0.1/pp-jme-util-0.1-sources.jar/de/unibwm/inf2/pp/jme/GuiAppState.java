//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme;

import org.checkerframework.checker.nullness.qual.EnsuresNonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

/**
 * App state that manages the lifecycle of a GUI component under control of a
 * dynamic activation predicate.
 *
 * <p>
 * This state encapsulates a common pattern in interactive applications: a GUI
 * shall exist only while a certain condition holds. The condition is supplied
 * as a {@link BooleanSupplier}. When it becomes {@code true}, a GUI instance is
 * created lazily and attached. When it becomes {@code false}, or when the GUI
 * reports itself invalid, the GUI is detached and discarded.
 * </p>
 *
 * <p>
 * GUI instances are created through a {@link Supplier}. Consequently, the
 * managed GUI may be recreated multiple times over the lifetime of the
 * application if the activation condition alternates between active and
 * inactive states.
 * </p>
 *
 * <h2>Lifecycle policy</h2>
 * <ul>
 *   <li>If no GUI is currently present and the activation predicate evaluates
 *       to {@code true}, a new GUI is created and attached.</li>
 *   <li>If a GUI is currently present and either the activation predicate
 *       evaluates to {@code false} or the GUI is no longer valid, the GUI is
 *       detached and discarded.</li>
 *   <li>If a GUI is present after the attachment/detachment phase, it receives
 *       a per-frame {@link Gui#update(float)} call.</li>
 * </ul>
 */
public class GuiAppState extends AppStateAdapter {

    /**
     * Minimal lifecycle for GUIs managed by {@link GuiAppState}.
     *
     * <p>Implementations encapsulate their own scene-graph nodes, input listeners,
     * and UI widgets. They are expected to be idempotent with respect to
     * {@link #attach()} and {@link #detach()} calls.</p>
     */
    public interface Gui {
        /**
         * Attaches the GUI to the scene and registers necessary input/listeners.
         * Called when the controlling feature becomes active.
         */
        void attach();

        /**
         * Detaches the GUI from the scene and unregisters listeners.
         * Called when the controlling feature becomes inactive.
         */
        void detach();

        /**
         * Per-frame update for the GUI. Default is a no-op.
         *
         * @param delta time per frame in seconds
         */
        default void update(float delta) {}

        /**
         * Indicates whether this GUI instance is still valid.
         *
         * <p>
         * Returning {@code false} causes the GUI to be detached and discarded on the next update.
         * The default implementation returns {@code true}.
         * </p>
         *
         * @return {@code true} if valid; {@code false} to force detachment
         */
        default boolean isValid() {
            return true;
        }
    }

    private final BooleanSupplier isActivated;
    private @Nullable Gui gui;
    private final Supplier<Gui> guiSupplier;

    /**
     * Creates a new GUI app state.
     *
     * @param guiSupplier factory for GUI instances (invoked lazily)
     * @param isActivated activation predicate controlling attach/detach
     */
    public GuiAppState(Supplier<Gui> guiSupplier, BooleanSupplier isActivated) {
        this.isActivated = Objects.requireNonNull(isActivated, "isActivated");
        this.guiSupplier = Objects.requireNonNull(guiSupplier, "guiSupplier");
    }

    /**
     * Frame update: attaches/detaches the GUI according to the controlling feature and updates it if present.
     *
     * <p>Behavior:</p>
     * <ol>
     *   <li>If the GUI must detach, call {@link Gui#detach()} and clear the reference.</li>
     *   <li>If the GUI must attach, create via {@code guiSupplier} and call {@link Gui#attach()}.</li>
     *   <li>If a GUI is attached, call {@link Gui#update(float)}.</li>
     * </ol>
     *
     * @param tpf time per frame in seconds
     */
    @Override
    public void update(float tpf) {
        if (mustDetach()) {
            gui.detach();
            gui = null;
        }
        if (mustAttach()) {
            gui = guiSupplier.get();
            gui.attach();
        }
        if (gui != null)
            gui.update(tpf);
    }

    /**
     * Returns whether the GUI should be created and attached in this update.
     */
    private boolean mustAttach() {
        return gui == null && isActivated.getAsBoolean();
    }

    /**
     * Returns whether the current GUI must be detached.
     *
     * <p>
     * Detachment occurs if the activation predicate is false or the GUI reports it is invalid.
     * </p>
     */
    @EnsuresNonNull("gui")
    @SuppressWarnings("contracts.postcondition")
    private boolean mustDetach() {
        return gui != null &&
               !(gui.isValid() && isActivated.getAsBoolean());
    }
}