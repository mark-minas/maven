//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

/**
 * Lemur-based dialog infrastructure and dialog-related UI models.
 *
 * <p>
 * This package provides a lightweight, reusable dialog layer built on top of
 * the Lemur GUI framework for jMonkeyEngine applications. Its central
 * abstraction is {@link de.unibwm.inf2.pp.jme.dialog.Dialog}, which represents a modal popup
 * dialog that can be opened and closed through a customized popup-management
 * state.
 * </p>
 *
 * <h2>Architectural structure</h2>
 * <p>
 * The package combines three closely related concerns:
 * </p>
 * <ul>
 *   <li><strong>Dialog abstractions</strong>, such as
 *       {@link de.unibwm.inf2.pp.jme.dialog.Dialog},
 *       {@link de.unibwm.inf2.pp.jme.dialog.LocalizedDialog},
 *       {@link de.unibwm.inf2.pp.jme.dialog.ConfirmDialog},
 *       {@link de.unibwm.inf2.pp.jme.dialog.ErrorDialog},
 *       {@link de.unibwm.inf2.pp.jme.dialog.FileDialog},
 *       and {@link de.unibwm.inf2.pp.jme.dialog.WaitDialog}.</li>
 *   <li><strong>Popup-state management</strong>, represented by
 *       {@link de.unibwm.inf2.pp.jme.dialog.DialogState}, which extends Lemur's popup support
 *       with explicit tracking of active dialogs.</li>
 *   <li><strong>Persistent UI models</strong>, such as
 *       {@link de.unibwm.inf2.pp.jme.dialog.PropertyCheckboxModel} and
 *       {@link de.unibwm.inf2.pp.jme.dialog.PropertyRangedValueModel}, which adapt
 *       preference-backed properties to Lemur model interfaces.</li>
 * </ul>
 *
 * <h2>Localization model</h2>
 * <p>
 * Reusable dialog chrome texts are abstracted through
 * {@link de.unibwm.inf2.pp.jme.dialog.DialogKey} and
 * {@link de.unibwm.inf2.pp.jme.dialog.DialogTextResolver}. This separates the semantic role of
 * a text fragment from its concrete representation and permits localization or
 * other context-dependent resolution strategies.
 * </p>
 *
 * <h2>Design intent</h2>
 * <p>
 * The classes in this package are intended to provide a small but coherent
 * dialog framework that remains independent of application-specific business
 * logic. Concrete dialog instances typically receive caller-supplied messages
 * and actions, while the framework contributes layout, popup handling, and
 * reusable user-interface conventions.
 * </p>
 */
package de.unibwm.inf2.pp.jme.dialog;