//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.assets;

/**
 * Enumeration of default texts used by the asset-preload layer.
 *
 * <p>
 * Each constant denotes a semantic preload-related message. The associated text
 * acts as a fallback used by a {@code PreloadTextResolver}.
 * </p>
 */
public enum PreloadKey {

    /**
     * Default message shown when asset preloading fails.
     */
    LOADING_FAILED("Loading assets failed:");

    /**
     * Default fallback text associated with this key.
     */
    private final String defaultText;

    /**
     * Creates a preload text key with its default fallback text.
     *
     * @param defaultText fallback text associated with the key
     */
    PreloadKey(String defaultText) {
        this.defaultText = defaultText;
    }

    /**
     * Returns the default fallback text of this key.
     *
     * @return the default text
     */
    public String defaultText() {
        return defaultText;
    }
}