//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

/**
 * General jMonkeyEngine support classes for application-state management,
 * GUI lifecycle control, and lightweight drawing utilities.
 *
 * <p>
 * This package provides small infrastructural abstractions that complement the
 * standard jMonkeyEngine API without replacing it. The contained classes are
 * intended to reduce recurring boilerplate in application-state handling,
 * conditional GUI attachment, and creation of simple geometric helper objects.
 * </p>
 *
 * <h2>Main abstractions</h2>
 * <ul>
 *   <li>{@link de.unibwm.inf2.pp.jme.AppStateAdapter}, a convenience base class with empty
 *       app-state lifecycle hooks.</li>
 *   <li>{@link de.unibwm.inf2.pp.jme.GuiAppState}, an app state that manages attachment and
 *       detachment of a GUI object according to a dynamic activation
 *       predicate.</li>
 *   <li>{@link de.unibwm.inf2.pp.jme.Draw}, a utility for creating simple reusable geometric
 *       primitives for overlays, debugging, and two-dimensional rendering
 *       tasks.</li>
 * </ul>
 *
 * <h2>Design rationale</h2>
 * <p>
 * The package emphasizes lightweight, explicit abstractions. Instead of
 * introducing a large framework layer, it provides narrowly scoped helper
 * classes that can be combined with standard jME mechanisms in a transparent
 * manner.
 * </p>
 */
package de.unibwm.inf2.pp.jme;