//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

/**
 * Asset-loading support and preload-related user-interface integration for
 * jMonkeyEngine applications.
 *
 * <p>
 * This package provides infrastructure for deterministic asset preloading on
 * the jME update thread together with small abstractions for presenting preload
 * progress and preload failures to the user.
 * </p>
 *
 * <h2>Core components</h2>
 * <ul>
 *   <li>{@link de.unibwm.inf2.pp.jme.assets.AssetPreloadAppState}, which executes preload
 *       tasks incrementally over successive frames.</li>
 *   <li>{@link de.unibwm.inf2.pp.jme.assets.DefaultPreloadListener}, which adapts preload
 *       progress and failure events to dialog-based user feedback.</li>
 *   <li>{@link de.unibwm.inf2.pp.jme.assets.PreloadKey} and
 *       {@link de.unibwm.inf2.pp.jme.assets.PreloadTextResolver}, which provide a small
 *       localization abstraction for preload-related texts.</li>
 * </ul>
 *
 * <h2>Processing model</h2>
 * <p>
 * Preload work is represented as a sequence of named tasks. These tasks are
 * executed on the application update loop, optionally constrained by a maximum
 * number of tasks per frame and by a time budget. This design avoids
 * uncontrolled frame stalls while preserving deterministic execution order.
 * </p>
 *
 * <h2>User-interface integration</h2>
 * <p>
 * The package deliberately separates preload execution from preload
 * presentation. The app state performs the technical work, whereas listener
 * implementations, such as {@link de.unibwm.inf2.pp.jme.assets.DefaultPreloadListener},
 * translate progress events into progress dialogs and translate failures into
 * user-facing diagnostics.
 * </p>
 */
package de.unibwm.inf2.pp.jme.assets;