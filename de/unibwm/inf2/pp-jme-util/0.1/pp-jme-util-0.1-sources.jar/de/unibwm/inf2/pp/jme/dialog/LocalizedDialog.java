//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

import java.util.Objects;

/**
 * Convenience base class for dialogs that use framework-defined localized
 * chrome texts.
 *
 * <p>
 * This class stores a {@link DialogTextResolver} instance and provides convenient
 * access to framework texts via {@link #text(DialogKey)}.
 * </p>
 */
public abstract class LocalizedDialog extends Dialog {

    /**
     * Typed access facade for framework-owned dialog texts.
     */
    private final DialogTextResolver texts;

    /**
     * Creates a localized dialog using the given typed text facade.
     *
     * @param texts typed dialog texts; must not be {@code null}
     * @throws NullPointerException if {@code texts} is {@code null}
     */
    protected LocalizedDialog(DialogTextResolver texts) {
        this.texts = Objects.requireNonNull(texts, "texts");
    }

    /**
     * Returns the localized framework text for the given key.
     *
     * @param key the framework text key
     * @return the localized string
     */
    protected final String text(DialogKey key) {
        return texts.get(key);
    }

    /**
     * Returns the typed dialog text facade associated with this dialog.
     *
     * @return the typed dialog texts
     */
    protected final DialogTextResolver texts() {
        return texts;
    }
}