//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

import com.jme3.input.KeyInput;
import com.simsilica.lemur.Button;
import com.simsilica.lemur.Container;
import com.simsilica.lemur.Label;
import com.simsilica.lemur.TextField;
import com.simsilica.lemur.component.BorderLayout;
import com.simsilica.lemur.component.SpringGridLayout;
import com.simsilica.lemur.event.KeyAction;
import com.simsilica.lemur.style.ElementId;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Objects;
import java.util.prefs.Preferences;

import static com.simsilica.lemur.component.BorderLayout.Position.East;
import static com.simsilica.lemur.component.BorderLayout.Position.West;

/**
 * Modal dialog for simple file operations driven by a user-entered path.
 *
 * <p>
 * The dialog is intentionally lightweight. It does not provide directory
 * browsing or a graphical file chooser; instead, it presents a single-line text
 * input field whose contents are passed to a caller-supplied {@link FileAction}
 * after confirmation.
 * </p>
 *
 * <p>
 * The framework localizes only reusable chrome texts, such as the file-path
 * field caption and generic button labels. The dialog title is supplied by the
 * caller and is expected to already be localized as needed.
 * </p>
 *
 * <h2>State persistence</h2>
 * <p>
 * The dialog remembers the last path entered by the user in a configurable
 * preferences entry. This allows different logical usages, such as “load map”
 * and “save map”, to maintain separate remembered paths if desired.
 * </p>
 */
public class FileDialog extends LocalizedDialog {

    /**
     * Default preferences node used by file dialogs.
     */
    private static final Preferences DEFAULT_PREFERENCES =
            Preferences.userNodeForPackage(FileDialog.class);

    /**
     * Default preferences key used if no explicit path key is supplied.
     */
    private static final String DEFAULT_LAST_PATH_KEY = "dialog.file.last-path"; // NON-NLS

    /**
     * Preferred width of the path input field.
     */
    private static final float PATH_FIELD_WIDTH = 500f;

    /**
     * Callback executed when the dialog is confirmed.
     */
    @FunctionalInterface
    public interface FileAction {

        /**
         * Executes the operation associated with the user-entered file path.
         *
         * @param file file constructed from the user-entered path
         * @throws IOException if the file operation fails
         */
        void run(File file) throws IOException;
    }

    /**
     * Operation executed when the user confirms the dialog.
     */
    private final FileAction onAcceptFile;

    /**
     * Title displayed at the top of the dialog.
     */
    private final String title;

    /**
     * Preferences node used to persist the last entered path.
     */
    private final Preferences preferences;

    /**
     * Preferences key under which the last entered path is stored.
     */
    private final String lastPathKey;

    /**
     * Creates a new file dialog using the default preferences location and key.
     *
     * @param onAcceptFile action executed when the user confirms the dialog; must not be
     *                     {@code null}
     * @param title        dialog title shown at the top; must not be {@code null}
     * @param texts        typed dialog texts providing framework chrome; must not be
     *                     {@code null}
     */
    public FileDialog(FileAction onAcceptFile,
                      String title,
                      DialogTextResolver texts) {
        this(onAcceptFile, title, DEFAULT_PREFERENCES, DEFAULT_LAST_PATH_KEY, texts);
    }

    /**
     * Creates a new file dialog using the given preferences configuration.
     *
     * @param onAcceptFile action executed when the user confirms the dialog; must not be
     *                     {@code null}
     * @param title        dialog title shown at the top; must not be {@code null}
     * @param preferences  preferences node used to persist the last entered path; must not
     *                     be {@code null}
     * @param lastPathKey  preferences key under which the last entered path is stored; must
     *                     neither be {@code null} nor blank
     * @param texts        typed dialog texts providing framework chrome; must not be
     *                     {@code null}
     */
    public FileDialog(FileAction onAcceptFile,
                      String title,
                      Preferences preferences,
                      String lastPathKey,
                      DialogTextResolver texts) {
        super(texts);
        this.onAcceptFile = Objects.requireNonNull(onAcceptFile, "onAcceptFile");
        this.title = Objects.requireNonNull(title, "title");
        this.preferences = Objects.requireNonNull(preferences, "preferences");
        this.lastPathKey = Objects.requireNonNull(lastPathKey, "lastPathKey");
        if (lastPathKey.isBlank()) {
            throw new IllegalArgumentException("lastPathKey must not be blank");
        }
    }

    @Override
    protected void initializeDialog() {
        final TextField pathField = new TextField(preferences.get(lastPathKey, "").trim());
        pathField.setSingleLine(true);
        pathField.setPreferredWidth(PATH_FIELD_WIDTH);
        pathField.getDocumentModel().right();

        addChild(new Label(title, new ElementId("header"))); // NON-NLS

        final Container line = addChild(new Container(new SpringGridLayout()));
        line.addChild(new Label(text(DialogKey.FILE_PATH_LABEL)));
        line.addChild(pathField, 1);

        final Container buttons = addChild(new Container(new BorderLayout()));
        final Button okButton = buttons.addChild(new Button(text(DialogKey.OK)), West);
        final Button cancelButton = buttons.addChild(new Button(text(DialogKey.CANCEL)), East);

        okButton.addClickCommands(_ -> confirm(pathField.getText().trim()));
        cancelButton.addClickCommands(_ -> close());

        mapKey(pathField, KeyInput.KEY_RETURN, okButton);
        mapKey(pathField, KeyInput.KEY_NUMPADENTER, okButton);
    }

    /**
     * Installs a key binding so that pressing the specified key while the given
     * text field has focus triggers a programmatic click on the specified
     * button.
     *
     * @param textField text field receiving the key event; must not be {@code null}
     * @param keyCode   key code to bind
     * @param button    button to activate; must not be {@code null}
     */
    private static void mapKey(TextField textField, int keyCode, Button button) {
        textField.getActionMap().put(new KeyAction(keyCode), (c, k) -> button.click());
    }

    /**
     * Executes the confirmation logic.
     *
     * <p>
     * If the entered path is blank, an {@link ErrorDialog} is shown and this
     * dialog remains open. Otherwise, the path is persisted, the configured file
     * action is executed, and the dialog closes on success. I/O errors are
     * reported via {@link ErrorDialog}, again leaving the dialog open so that
     * the user can correct the path and retry.
     * </p>
     */
    private void confirm(String path) {
        if (path.isEmpty()) {
            new ErrorDialog(text(DialogKey.FILE_ERROR_EMPTY_PATH), texts()).open();
            return;
        }

        try {
            preferences.put(lastPathKey, path);
            onAcceptFile.run(new File(path));
            close();
        }
        catch (FileNotFoundException _) {
            new ErrorDialog(text(DialogKey.FILE_NOT_FOUND) + ": " + path, texts()).open();
        }
        catch (IOException e) {
            final String msg = e.getLocalizedMessage();
            new ErrorDialog(msg != null ? msg : "unspecified error", texts()).open();
        }
    }
}