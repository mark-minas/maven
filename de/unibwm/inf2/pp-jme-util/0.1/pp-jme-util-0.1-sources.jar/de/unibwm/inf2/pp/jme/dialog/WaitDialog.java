//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.control.AbstractControl;
import com.simsilica.lemur.Label;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.text.MessageFormat;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.function.Consumer;

/**
 * Modal dialog that monitors completion of a background {@link Future}.
 *
 * <p>
 * The dialog displays a single status label whose text is periodically updated
 * according to a caller-supplied {@link MessageFormat} pattern receiving the
 * elapsed time in whole seconds as argument {@code 0}.
 * </p>
 *
 * <p>
 * Completion is detected by polling {@link Future#isDone()} on the update
 * thread. Once completion has been observed, {@link Future#get()} is invoked in
 * order to distinguish normal from exceptional completion. The render thread is
 * therefore not blocked while the future is still running.
 * </p>
 */
public class WaitDialog extends Dialog {

    /**
     * Logger used for exceptional monitoring conditions.
     */
    private static final Logger LOGGER = System.getLogger(WaitDialog.class.getName());

    /**
     * Monitored background future.
     */
    private final Future<?> future;

    /**
     * {@link MessageFormat} pattern receiving elapsed seconds as argument 0.
     */
    private final String messagePattern;

    /**
     * Label displaying the current status text.
     */
    private final Label statusLabel = new Label("");

    /**
     * Action executed after normal completion.
     */
    private final Runnable onSuccess;

    /**
     * Action executed after exceptional completion.
     */
    private final Consumer<Throwable> onFailure;

    /**
     * Creates a new wait dialog.
     *
     * @param future         future to monitor; must not be {@code null}
     * @param messagePattern message pattern receiving elapsed seconds as argument 0; must not
     *                       be {@code null}
     * @param onSuccess      action executed after normal completion; must not be
     *                       {@code null}
     * @param onFailure      action executed after exceptional completion; must not be
     *                       {@code null}
     */
    public WaitDialog(Future<?> future,
                      String messagePattern,
                      Runnable onSuccess,
                      Consumer<Throwable> onFailure) {
        this.future = Objects.requireNonNull(future, "future");
        this.messagePattern = Objects.requireNonNull(messagePattern, "messagePattern");
        this.onSuccess = Objects.requireNonNull(onSuccess, "onSuccess");
        this.onFailure = Objects.requireNonNull(onFailure, "onFailure");
    }

    @Override
    protected void initializeDialog() {
        updateElapsedSeconds(0);
        addChild(statusLabel);
        addControl(new FutureMonitorControl());
    }

    /**
     * Updates the status text for the given elapsed duration.
     *
     * @param elapsedSeconds elapsed duration in whole seconds
     */
    private void updateElapsedSeconds(int elapsedSeconds) {
        statusLabel.setText(MessageFormat.format(messagePattern, elapsedSeconds));
    }

    /**
     * Control that monitors the background future and updates elapsed time.
     */
    private final class FutureMonitorControl extends AbstractControl {

        /**
         * Indicates whether terminal handling has already occurred.
         */
        private boolean finished;

        /**
         * Elapsed time in seconds since dialog initialization.
         */
        private float elapsedSeconds;

        @Override
        protected void controlUpdate(float delta) {
            final int previousWholeSeconds = (int) elapsedSeconds;
            elapsedSeconds += delta;
            final int currentWholeSeconds = (int) elapsedSeconds;

            if (currentWholeSeconds != previousWholeSeconds) {
                updateElapsedSeconds(currentWholeSeconds);
            }

            if (finished || !future.isDone()) {
                return;
            }

            try {
                future.get();
                finished = true;
                close();
                onSuccess.run();
            }
            catch (ExecutionException e) {
                finished = true;
                close();
                final Throwable cause = e.getCause();
                onFailure.accept(cause != null ? cause : e);
            }
            catch (InterruptedException e) {
                finished = true;
                close();
                LOGGER.log(Level.WARNING, "Interrupted while monitoring background future.", e);
                Thread.currentThread().interrupt();
                onFailure.accept(e);
            }
        }

        @Override
        protected void controlRender(RenderManager renderManager, ViewPort viewPort) {
            /* no-op */
        }
    }
}