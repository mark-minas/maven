//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

/**
 * Strategy interface for resolving framework-owned dialog texts.
 *
 * <p>
 * This interface abstracts the lookup of reusable texts employed by the dialog
 * layer, such as button captions, dialog titles, and validation messages. The
 * semantic identity of a text fragment is represented by {@link DialogKey},
 * whereas the concrete string value is supplied by an implementation of this
 * interface.
 * </p>
 *
 * <p>
 * The default implementation returns the fallback text stored directly in the
 * given key. Applications may override this behavior in order to integrate
 * resource-bundle based localization or other text-resolution mechanisms.
 * </p>
 */
public interface DialogTextResolver {

    /**
     * Resolves the text associated with the given dialog key.
     *
     * @param key dialog text key
     * @return resolved text for the given key
     */
    default String get(DialogKey key) {return key.defaultText();}
}