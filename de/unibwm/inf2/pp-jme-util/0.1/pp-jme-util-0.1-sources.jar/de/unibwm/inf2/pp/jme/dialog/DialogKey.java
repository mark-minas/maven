//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

/**
 * Enumeration of default texts used by the dialog layer.
 *
 * <p>
 * Each constant represents a semantic dialog text fragment, such as a button
 * caption, dialog title, or validation message. The associated string serves as
 * the fallback text used by {@link DialogTextResolver}.
 * </p>
 *
 * <p>
 * The enumeration separates dialog semantics from concrete UI classes and
 * supports centralized text management.
 * </p>
 */
public enum DialogKey {

    /**
     * Default caption of a confirmation button.
     */
    OK("Ok"),

    /**
     * Default caption of a cancel button.
     */
    CANCEL("Cancel"),

    /**
     * Default caption of an affirmative button.
     */
    YES("Yes"),

    /**
     * Default caption of a negative button.
     */
    NO("No"),

    /**
     * Default title of a confirmation dialog.
     */
    CONFIRM_TITLE("Question"),

    /**
     * Default title of an error dialog.
     */
    ERROR_TITLE("Note"),

    /**
     * Default caption of the file-path input field.
     */
    FILE_PATH_LABEL("File:"),

    /**
     * Default message used for an empty file path.
     */
    FILE_ERROR_EMPTY_PATH("Please enter a file path."),

    /**
     * Default message used when a file cannot be found.
     */
    FILE_NOT_FOUND("File not found");

    /**
     * Default fallback text associated with this key.
     */
    private final String defaultText;

    /**
     * Creates a dialog text key with its default fallback text.
     *
     * @param defaultText fallback text associated with the key
     */
    DialogKey(String defaultText) {
        this.defaultText = defaultText;
    }

    /**
     * Returns the default fallback text of this key.
     *
     * @return the default text
     */
    public String defaultText() {
        return defaultText;
    }
}