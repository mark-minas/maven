//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

import com.simsilica.lemur.Button;
import com.simsilica.lemur.Container;
import com.simsilica.lemur.Label;
import com.simsilica.lemur.component.BorderLayout;
import com.simsilica.lemur.style.ElementId;

import java.util.Objects;

import static com.simsilica.lemur.component.BorderLayout.Position.West;

/**
 * Modal dialog for displaying a user-facing error message.
 *
 * <p>
 * The dialog consists of a framework-localized title, a caller-supplied message
 * body, and a framework-localized acknowledgment button. The concrete error
 * message is supplied by the caller and is expected to be suitable for direct
 * display to the user.
 * </p>
 */
public class ErrorDialog extends LocalizedDialog {

    /**
     * User-facing message shown in the dialog body.
     */
    private final String message;

    /**
     * Action executed after the dialog has been acknowledged and closed.
     */
    private final Runnable onClose;

    /**
     * Creates a new error dialog.
     *
     * @param message user-facing error message; must not be {@code null}
     * @param onClose action executed after the dialog is closed; must not be
     *                {@code null}
     * @param texts   typed dialog texts providing framework chrome; must not be
     *                {@code null}
     */
    public ErrorDialog(String message,
                       Runnable onClose,
                       DialogTextResolver texts) {
        super(texts);
        this.message = Objects.requireNonNull(message, "message");
        this.onClose = Objects.requireNonNull(onClose, "onClose");
    }

    /**
     * Creates a new error dialog without an additional close action.
     *
     * @param message user-facing error message; must not be {@code null}
     * @param texts   typed dialog texts providing framework chrome; must not be
     *                {@code null}
     */
    public ErrorDialog(String message,
                       DialogTextResolver texts) {
        this(message, () -> {}, texts);
    }

    @Override
    protected void initializeDialog() {
        addChild(new Label(text(DialogKey.ERROR_TITLE), new ElementId("header"))); // NON-NLS
        addChild(new Label(message));

        final Container buttons = addChild(new Container(new BorderLayout()));
        final Button okButton = buttons.addChild(new Button(text(DialogKey.OK)), West);
        okButton.addClickCommands(_ -> {
            close();
            onClose.run();
        });
    }
}