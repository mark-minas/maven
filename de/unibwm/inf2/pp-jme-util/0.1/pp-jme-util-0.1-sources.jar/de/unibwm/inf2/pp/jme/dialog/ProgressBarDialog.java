//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

import com.simsilica.lemur.DefaultRangedValueModel;
import com.simsilica.lemur.Label;
import com.simsilica.lemur.ProgressBar;
import com.simsilica.lemur.RangedValueModel;
import com.simsilica.lemur.style.ElementId;

import java.util.Objects;

/**
 * Modal dialog displaying a progress bar and a percentage label.
 *
 * <p>
 * The dialog is intended for long-running operations such as loading assets or
 * generating game state. Progress is represented as a normalized value in the
 * closed interval {@code [0.0, 1.0]}.
 * </p>
 */
public class ProgressBarDialog extends Dialog {

    /**
     * Progress model storing normalized progress values.
     */
    private final RangedValueModel progressModel = new DefaultRangedValueModel(0, 1, 0);

    /**
     * Progress-bar widget bound to {@link #progressModel}.
     */
    private final ProgressBar progressBar = new ProgressBar(progressModel);

    /**
     * Title shown at the top of the dialog.
     */
    private final String title;

    /**
     * Creates a new progress-bar dialog.
     *
     * @param title title displayed at the top of the dialog; must not be
     *              {@code null}
     */
    public ProgressBarDialog(String title) {
        this.title = Objects.requireNonNull(title, "title");
    }

    @Override
    protected void initializeDialog() {
        addChild(new Label(title, new ElementId("header"))); // NON-NLS
        addChild(progressBar);
        setProgress(0d);
    }

    /**
     * Sets the normalized progress value.
     *
     * @param value normalized progress value in {@code [0.0, 1.0]}
     * @throws IllegalArgumentException if {@code value} lies outside {@code [0.0, 1.0]}
     */
    public void setProgress(double value) {
        if (value < 0d || value > 1d)
            throw new IllegalArgumentException("value must be between 0.0 and 1.0");

        progressModel.setValue(value);
        progressBar.setMessage("%3.0f%%".formatted(Math.floor(100d * value)));
    }

    /**
     * Returns the current normalized progress value.
     *
     * @return the current progress in {@code [0.0, 1.0]}
     */
    public double getProgress() {
        return progressModel.getValue();
    }

    /**
     * Compatibility alias for {@link #setProgress(double)}.
     *
     * @param value normalized progress value
     */
    public void setValue(double value) {
        setProgress(value);
    }

    /**
     * Compatibility alias for {@link #getProgress()}.
     *
     * @return the current normalized progress
     */
    public double getValue() {
        return getProgress();
    }
}