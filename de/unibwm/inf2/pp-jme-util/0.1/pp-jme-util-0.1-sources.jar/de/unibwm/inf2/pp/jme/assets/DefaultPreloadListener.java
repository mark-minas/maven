//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.assets;

import de.unibwm.inf2.pp.jme.assets.AssetPreloadAppState.Failure;
import de.unibwm.inf2.pp.jme.dialog.ErrorDialog;
import de.unibwm.inf2.pp.jme.dialog.ProgressBarDialog;
import org.checkerframework.checker.nullness.qual.EnsuresNonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Default listener that translates asset-preload events into dialog-based user
 * feedback.
 *
 * <p>
 * This class constitutes a presentation-oriented companion to
 * {@link AssetPreloadAppState}. It receives progress, completion, and failure
 * events and reacts by opening, updating, or closing a
 * {@link ProgressBarDialog}, and by showing an {@link ErrorDialog} in the event
 * of preload failure.
 * </p>
 *
 * <p>
 * The listener thereby separates the technical execution of preload tasks from
 * their user-interface representation. In particular, it does not perform any
 * asset loading itself; rather, it translates preload-state changes into a
 * simple dialog-driven interaction model.
 * </p>
 *
 * <h2>Failure handling</h2>
 * <p>
 * If one or more preload tasks fail, the progress dialog is closed and a single
 * error dialog is opened that summarizes all encountered failures. After user
 * acknowledgement, the configured failure callback is executed.
 * </p>
 *
 * <h2>Completion handling</h2>
 * <p>
 * On successful completion, the progress dialog is closed and the configured
 * completion callback is invoked.
 * </p>
 */
public class DefaultPreloadListener {
    /**
     * Title shown in the progress dialog.
     */
    private final String title;

    /**
     * Resolver providing preload-related and dialog-related texts.
     */
    private final PreloadTextResolver bundle;

    /**
     * Action executed after successful preload completion.
     */
    private final Runnable onComplete;

    /**
     * Action executed after preload failure has been acknowledged.
     */
    private final Runnable onFailure;

    /**
     * Creates a new preload listener with dialog-based default behavior.
     *
     * @param title      title shown in the progress dialog; must not be {@code null}
     * @param bundle     text resolver used for preload-related user-interface texts;
     *                   must not be {@code null}
     * @param onComplete action executed after successful preload completion; must
     *                   not be {@code null}
     * @param onFailure  action executed after preload failure has been reported and
     *                   acknowledged; must not be {@code null}
     */
    public DefaultPreloadListener(String title, PreloadTextResolver bundle, Runnable onComplete, Runnable onFailure) {
        this.title = Objects.requireNonNull(title, "title");
        this.bundle = Objects.requireNonNull(bundle, "bundle");
        this.onComplete = Objects.requireNonNull(onComplete, "onComplete");
        this.onFailure = Objects.requireNonNull(onFailure, "onFailure");
    }

    /**
     * Lazily created progress dialog shown during asset preload.
     */
    private @Nullable ProgressBarDialog progressDialog;

    /**
     * Receives incremental preload progress and updates the progress dialog.
     *
     * <p>
     * The progress dialog is created on first demand. Progress is expressed as a
     * normalized fraction derived from {@code loadedCount} and
     * {@code totalCount}. If {@code totalCount} is zero, progress is treated as
     * complete.
     * </p>
     *
     * @param loadedCount number of successfully processed or attempted assets
     * @param totalCount  total number of declared assets
     * @param currentPath name or path of the most recently processed task
     */
    public void onProgress(int loadedCount, int totalCount, String currentPath) {
        openProgressDialog();
        final double percentage = totalCount == 0 ? 1.0 : loadedCount / (double) totalCount;
        Objects.requireNonNull(progressDialog).setValue(percentage);
    }

    /**
     * Handles preload failure by closing the progress dialog and presenting a
     * summarized diagnostic report.
     *
     * <p>
     * The report consists of a localized headline and one line per recorded
     * failure. After the resulting error dialog has been acknowledged by the
     * user, the configured failure callback is executed.
     * </p>
     *
     * @param failures encountered failures; must not be {@code null}
     */
    public void onFailure(List<Failure> failures) {
        closeProgressDialog();

        final PreloadKey key = PreloadKey.LOADING_FAILED;
        final String failedPaths = failures.stream().map(DefaultPreloadListener::failure).collect(Collectors.joining("\n"));

        new ErrorDialog(bundle.get(key) + '\n' + failedPaths, onFailure, bundle).open();
    }

    /**
     * Formats a single failure entry for diagnostic display.
     *
     * @param failure failure descriptor
     * @return formatted user-facing failure line
     */
    private static String failure(Failure failure) {
        return failure.taskName() + " (" + failure.exception().getMessage() + ")";
    }

    /**
     * Handles successful preload completion.
     *
     * <p>
     * The progress dialog is closed, if present, and the configured completion
     * callback is invoked.
     * </p>
     */
    public void onComplete() {
        closeProgressDialog();
        onComplete.run();
    }

    /**
     * Opens the progress dialog if it has not yet been created.
     */
    @EnsuresNonNull("progressDialog")
    private void openProgressDialog() {
        if (progressDialog != null) return;
        progressDialog = new ProgressBarDialog(title);
        progressDialog.open();
        assert progressDialog != null : "@AssumeAssertion(nullness)";
    }

    /**
     * Closes the progress dialog if one is currently open.
     */
    private void closeProgressDialog() {
        if (progressDialog == null) return;
        progressDialog.close();
        progressDialog = null;
    }
}