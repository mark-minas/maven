//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

import com.jme3.math.ColorRGBA;
import com.jme3.scene.Spatial;
import com.simsilica.lemur.Command;
import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.event.PopupState;
import org.checkerframework.checker.nullness.qual.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Project-specific {@link PopupState} that tracks currently active popups in
 * display order.
 *
 * <p>
 * Lemur's default popup handling does not expose a first-class stack
 * abstraction. This implementation records the popups shown through it so that
 * clients can inspect the topmost active popup and so that focus and cursor
 * access can be restored to the next popup when the current one closes.
 * </p>
 *
 * <p>
 * The internal order is the popup display order: the most recently shown popup
 * is considered topmost. Since close requests may target arbitrary popups, the
 * tracked structure should be understood as an ordered active-popup list rather
 * than as a strict push/pop stack.
 * </p>
 */
public class DialogState extends PopupState {

    /**
     * Active popups in display order.
     */
    private final List<Spatial> activePopups = new ArrayList<>();

    /**
     * Creates a new dialog popup state.
     */
    public DialogState() { /* empty */ }

    /**
     * Shows the specified popup and records it in the active-popup list.
     *
     * <p>
     * The supplied close command, if any, is wrapped so that popup bookkeeping
     * can be maintained consistently when the popup is dismissed.
     * </p>
     *
     * @param popup           the popup spatial to display; must not be {@code null}
     * @param clickMode       defines how clicks outside the popup are handled
     * @param closeCommand    optional callback executed when the popup is closed
     * @param backgroundColor background blocker color
     */
    @Override
    public void showPopup(Spatial popup,
                          ClickMode clickMode,
                          @Nullable Command<? super PopupState> closeCommand,
                          ColorRGBA backgroundColor) {
        final Spatial nonNullPopup = Objects.requireNonNull(popup, "popup");
        super.showPopup(nonNullPopup, clickMode,
                        new CloseCommand(closeCommand, nonNullPopup),
                        backgroundColor);
        activePopups.add(nonNullPopup);
    }

    /**
     * Returns the topmost active popup.
     *
     * @return an {@link Optional} containing the topmost active popup, or an
     * empty optional if none are active
     */
    public Optional<Spatial> top() {
        return activePopups.isEmpty()
                ? Optional.empty()
                : Optional.of(activePopups.getLast());
    }

    /**
     * Returns the number of currently active popups.
     *
     * @return the number of active popups
     */
    public int popupCount() {
        return activePopups.size();
    }

    /**
     * Close-command wrapper that updates popup bookkeeping and then delegates to
     * an optional wrapped command.
     */
    private final class CloseCommand implements Command<PopupState> {

        /**
         * Optional caller-supplied close command.
         */
        private final @Nullable Command<? super PopupState> wrappedCommand;

        /**
         * Popup associated with this close command.
         */
        private final Spatial popup;

        /**
         * Creates a new close-command wrapper.
         *
         * @param wrappedCommand optional wrapped command
         * @param popup          popup associated with the command; must not be {@code null}
         */
        private CloseCommand(@Nullable Command<? super PopupState> wrappedCommand, Spatial popup) {
            this.wrappedCommand = wrappedCommand;
            this.popup = Objects.requireNonNull(popup, "popup");
        }

        /**
         * Updates popup bookkeeping, delegates to the wrapped command if
         * present, and restores focus/cursor access to the next topmost popup
         * if one remains.
         *
         * @param source the popup state executing the command
         */
        @Override
        public void execute(PopupState source) {
            activePopups.remove(popup);

            if (wrappedCommand != null)
                wrappedCommand.execute(source);

            if (!activePopups.isEmpty()) {
                final Spatial newTop = activePopups.getLast();
                GuiGlobals.getInstance().requestCursorEnabled(this);
                GuiGlobals.getInstance().requestFocus(newTop);
            }
        }
    }
}