//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

import com.jme3.app.Application;
import com.jme3.app.state.AppStateManager;
import com.simsilica.lemur.Container;
import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.event.PopupState;
import com.simsilica.lemur.style.BaseStyles;

import java.util.Objects;

/**
 * Abstract base class for modal dialogs implemented with the Lemur GUI
 * framework.
 *
 * <p>
 * A {@code Dialog} is a {@link Container} that can be displayed as a centered
 * modal popup via Lemur's {@link PopupState}. The class additionally provides a
 * project-specific initialization routine that installs {@link DialogState} as
 * the active popup state and loads the project's default style.
 * </p>
 *
 * <h2>Lifecycle</h2>
 * <ol>
 *   <li>Invoke {@link #initialize(Application)} once during application startup.</li>
 *   <li>Create dialog instances as needed.</li>
 *   <li>Call {@link #open()} to display a dialog modally.</li>
 *   <li>Call {@link #close()} to dismiss a dialog.</li>
 * </ol>
 *
 * <h2>Lazy UI construction</h2>
 * <p>
 * Dialog subclasses implement {@link #initializeDialog()} in order to build
 * their widgets. This initialization is performed lazily on the first call to
 * {@link #open()} and is not repeated afterwards.
 * </p>
 *
 * <h2>Thread safety</h2>
 * <p>
 * Instances of this class are not thread-safe and are intended to be used on
 * the GUI thread.
 * </p>
 */
public abstract class Dialog extends Container {

    /**
     * Path to the Groovy style script defining the project's Lemur styles.
     */
    private static final String STYLES_SCRIPT = "Interface/Lemur/pp-styles.groovy"; // NON-NLS

    /**
     * Name of the default style applied after initialization.
     */
    private static final String DEFAULT_STYLE = "pp"; // NON-NLS

    /**
     * Indicates whether the dialog subsystem has been initialized for the
     * current application.
     */
    private static boolean globallyInitialized;

    /**
     * Indicates whether this dialog instance has already built its widget tree.
     */
    private boolean initialized;

    /**
     * Creates a new dialog instance.
     */
    protected Dialog() { /* empty */ }

    /**
     * Initializes the dialog subsystem for the given application.
     *
     * <p>
     * This method installs a project-specific {@link DialogState}, replaces the
     * original Lemur popup state, and loads the default style resources. The
     * method is idempotent for the current JVM process: repeated invocations
     * after successful initialization are ignored.
     * </p>
     *
     * @param app the owning application; must not be {@code null}
     * @throws NullPointerException if {@code app} is {@code null}
     */
    public static synchronized void initialize(Application app) {
        Objects.requireNonNull(app, "app");

        if (globallyInitialized)
            return;

        final MyGuiGlobals globals = new MyGuiGlobals(app);
        final AppStateManager stateManager = app.getStateManager();
        stateManager.attach(globals.getPopupState());
        stateManager.detach(globals.getOriginalPopupState());
        GuiGlobals.setInstance(globals);
        BaseStyles.loadStyleResources(STYLES_SCRIPT);
        GuiGlobals.getInstance().getStyles().setDefaultStyle(DEFAULT_STYLE);

        globallyInitialized = true;
    }

    /**
     * Returns whether at least one popup dialog is currently open.
     *
     * @return {@code true} if there is at least one active popup;
     * {@code false} otherwise
     * @throws IllegalStateException if the dialog subsystem has not been initialized
     */
    public static boolean anyOpenDialog() {
        return popupState().hasActivePopups();
    }

    /**
     * Opens this dialog as a centered modal popup.
     *
     * <p>
     * On the first invocation for a given dialog instance,
     * {@link #initializeDialog()} is executed in order to build the widget tree.
     * Subsequent invocations reuse the existing widgets.
     * </p>
     *
     * @throws IllegalStateException if the dialog subsystem has not been initialized
     */
    public void open() {
        ensureInitialized();
        final PopupState popupState = popupState();
        popupState.centerInGui(this);
        popupState.showModalPopup(this);
    }

    /**
     * Closes this dialog by removing it from the popup state.
     *
     * <p>
     * If the dialog is not currently open, Lemur treats the operation as a
     * no-op.
     * </p>
     *
     * @throws IllegalStateException if the dialog subsystem has not been initialized
     */
    public void close() {
        popupState().closePopup(this);
    }

    /**
     * Builds the widget hierarchy of this dialog.
     *
     * <p>
     * Subclasses override this method in order to populate the container with
     * labels, buttons, and other controls. The method is invoked lazily exactly
     * once per dialog instance.
     * </p>
     */
    protected abstract void initializeDialog();

    /**
     * Ensures that this dialog instance has initialized its widgets.
     */
    private void ensureInitialized() {
        if (!initialized) {
            initializeDialog();
            initialized = true;
        }
    }

    /**
     * Returns the active popup state used by the dialog subsystem.
     *
     * @return the active popup state
     * @throws IllegalStateException if the dialog subsystem has not been initialized
     */
    protected static PopupState popupState() {
        final GuiGlobals globals = GuiGlobals.getInstance();
        if (globals == null)
            throw new IllegalStateException("Dialog subsystem not initialized. Call Dialog.initialize(Application) first.");
        return globals.getPopupState();
    }

    /**
     * Customized {@link GuiGlobals} that provides {@link DialogState} instead of
     * Lemur's original popup state.
     */
    private static final class MyGuiGlobals extends GuiGlobals {

        /**
         * Project-specific popup state.
         */
        private final DialogState popupState = new DialogState();

        /**
         * Creates a new customized globals instance.
         *
         * @param app the owning application
         */
        MyGuiGlobals(Application app) {
            super(app);
        }

        @Override
        public PopupState getPopupState() {
            return popupState;
        }

        /**
         * Returns the original popup state created by {@link GuiGlobals}.
         *
         * @return the original Lemur popup state
         */
        PopupState getOriginalPopupState() {
            return super.getPopupState();
        }
    }
}