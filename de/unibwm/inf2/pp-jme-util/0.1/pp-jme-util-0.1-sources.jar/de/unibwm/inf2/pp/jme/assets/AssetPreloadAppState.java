//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.assets;

import com.jme3.app.Application;
import com.jme3.app.state.AbstractAppState;
import com.jme3.app.state.AppStateManager;
import org.checkerframework.checker.nullness.qual.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

/**
 * App state for deterministic, incremental asset preloading on the jME update
 * loop.
 *
 * <p>
 * The state executes a finite sequence of named preload tasks on the same
 * thread that invokes {@link #update(float)}. Task execution is spread across
 * frames in order to control frame-time impact. Two throttling mechanisms are
 * supported:
 * </p>
 * <ul>
 *   <li>a maximum number of attempted tasks per frame, and</li>
 *   <li>an optional per-frame time budget measured in nanoseconds.</li>
 * </ul>
 *
 * <p>
 * The state reports progress after each attempted task and distinguishes
 * successful overall completion from failure completion. Individual task
 * failures do not abort the preload process immediately; instead, they are
 * accumulated and reported collectively once all tasks have been attempted.
 * </p>
 *
 * <h2>Execution semantics</h2>
 * <p>
 * Tasks are processed strictly in list order. Each task is attempted at most
 * once. If a task throws an exception, the exception is recorded in a
 * {@link Failure} object and processing continues with the next task.
 * </p>
 *
 * <h2>Lifecycle</h2>
 * <p>
 * Once all tasks have been processed, the state detaches itself from the
 * {@link AppStateManager}. It then invokes either the configured completion
 * action or the configured failure consumer, depending on whether any failures
 * were recorded.
 * </p>
 */
public class AssetPreloadAppState extends AbstractAppState {

    /**
     * Listener receiving progress events after each attempted task.
     */
    @FunctionalInterface
    public interface ProgressListener {

        /**
         * Reports current preload progress.
         *
         * @param attempted   number of tasks already attempted
         * @param total       total number of tasks
         * @param currentName name of the most recently attempted task
         */
        void onProgress(int attempted, int total, String currentName);
    }

    /**
     * Value object representing a single preload failure.
     *
     * @param taskName  logical task name
     * @param exception exception thrown by the task
     */
    public record Failure(String taskName, Exception exception) {}

    /**
     * Value object representing one named preload action.
     *
     * @param taskName  logical task name
     * @param preloader preloading action to execute
     */
    public record PreloadTask(String taskName, Runnable preloader) {}

    /**
     * Preload tasks to be executed in deterministic order.
     */
    private final List<PreloadTask> tasks;

    /**
     * Maximum number of tasks attempted per frame.
     */
    private final int maxTasksPerFrame;

    /**
     * Optional per-frame time budget in nanoseconds; zero disables the budget.
     */
    private final long timeBudgetNanos;

    /**
     * Optional listener receiving progress updates.
     */
    private final ProgressListener progressListener;

    /**
     * Action executed if all tasks complete without recorded failures.
     */
    private final Runnable onComplete;

    /**
     * Action executed if one or more failures were recorded.
     */
    private final Consumer<List<Failure>> onFailure;

    /**
     * Index of the next task to execute.
     */
    private int index = 0;

    /**
     * Failures recorded so far.
     */
    private final List<Failure> failures = new ArrayList<>();

    /**
     * Owning application, set during initialization.
     */
    private @Nullable Application app;

    /**
     * Creates a new preload state using a default dialog-based listener.
     *
     * @param tasks            preload tasks to execute
     * @param maxTasksPerFrame maximum number of tasks attempted per frame; must be
     *                         at least {@code 1}
     * @param timeBudgetNanos  optional time budget per frame in nanoseconds; values
     *                         below zero are treated as zero
     * @param listener         default preload listener used for progress, success,
     *                         and failure reporting
     */
    public AssetPreloadAppState(List<PreloadTask> tasks,
                                int maxTasksPerFrame,
                                long timeBudgetNanos,
                                DefaultPreloadListener listener) {
        this(tasks, maxTasksPerFrame, timeBudgetNanos, listener::onProgress, listener::onComplete, listener::onFailure);
    }

    /**
     * Creates a new preload state with explicit callbacks.
     *
     * @param tasks            preload tasks to execute in deterministic order; must
     *                         not be {@code null}
     * @param maxTasksPerFrame maximum number of tasks attempted per frame; must be
     *                         at least {@code 1}
     * @param timeBudgetNanos  optional time budget per frame in nanoseconds; values
     *                         below zero are treated as zero
     * @param progressListener optional listener receiving progress updates
     * @param onComplete       action executed on successful overall completion; must
     *                         not be {@code null}
     * @param onFailure        consumer receiving recorded failures on unsuccessful
     *                         overall completion; must not be {@code null}
     * @throws NullPointerException     if {@code tasks}, {@code onComplete}, or
     *                                  {@code onFailure} is {@code null}
     * @throws IllegalArgumentException if {@code maxTasksPerFrame < 1}
     */
    public AssetPreloadAppState(List<PreloadTask> tasks,
                                int maxTasksPerFrame,
                                long timeBudgetNanos,
                                ProgressListener progressListener,
                                Runnable onComplete,
                                Consumer<List<Failure>> onFailure) {

        this.tasks = List.copyOf(Objects.requireNonNull(tasks, "tasks"));
        if (maxTasksPerFrame < 1)
            throw new IllegalArgumentException("maxTasksPerFrame must be >= 1");

        this.maxTasksPerFrame = maxTasksPerFrame;
        this.timeBudgetNanos = Math.max(0L, timeBudgetNanos);
        this.progressListener = progressListener;
        this.onComplete = Objects.requireNonNull(onComplete, "onComplete");
        this.onFailure = Objects.requireNonNull(onFailure, "onFailure");
    }

    /**
     * Initializes this preload state and emits an initial progress event.
     *
     * @param stateManager owning app-state manager
     * @param app          owning application
     */
    @Override
    public void initialize(AppStateManager stateManager, Application app) {
        super.initialize(stateManager, app);
        this.app = app;
        if (progressListener != null)
            progressListener.onProgress(0, tasks.size(), "");
    }

    /**
     * Executes preload work for the current frame.
     *
     * <p>
     * Tasks are processed sequentially until one of the following conditions
     * holds:
     * </p>
     * <ul>
     *   <li>all tasks have been processed,</li>
     *   <li>the per-frame task limit has been reached, or</li>
     *   <li>the optional time budget has been exhausted.</li>
     * </ul>
     *
     * @param tpf time per frame in seconds
     */
    @Override
    public void update(float tpf) {
        if (index >= tasks.size()) {
            terminate();
            return;
        }

        final long start = System.nanoTime();
        int executed = 0;

        while (index < tasks.size() && executed < maxTasksPerFrame) {
            if (timeBudgetNanos > 0L && (System.nanoTime() - start) >= timeBudgetNanos) break;

            final PreloadTask pTask = tasks.get(index);
            final String name = pTask.taskName();
            final Runnable task = pTask.preloader();
            index++;
            executed++;

            try {
                task.run();
            }
            catch (Exception ex) {
                failures.add(new Failure(name, ex));
            }

            if (progressListener != null) progressListener.onProgress(index, tasks.size(), name);
        }

        if (index >= tasks.size()) terminate();
    }

    /**
     * Finishes preload processing, detaches this state, and dispatches the final
     * completion or failure callback.
     */
    private void terminate() {
        if (app == null) return;
        final AppStateManager sm = app.getStateManager();
        if (sm != null) sm.detach(this);
        if (failures.isEmpty())
            onComplete.run();
        else
            onFailure.accept(List.copyOf(failures));
    }
}