package de.unibwm.inf2.pp.jme.assets;

import de.unibwm.inf2.pp.jme.dialog.DialogTextResolver;

/**
 * Strategy interface for resolving preload-related user-interface texts.
 *
 * <p>
 * This interface extends {@link DialogTextResolver} because preload-related UI
 * components may require both the general dialog texts defined by the dialog
 * layer and the preload-specific texts defined in this package.
 * </p>
 *
 * <p>
 * The default implementation returns the fallback text stored directly in the
 * corresponding {@link PreloadKey}. Implementations may override this behavior
 * in order to provide localized or otherwise externally configured text
 * resolution.
 * </p>
 */
public interface PreloadTextResolver extends DialogTextResolver {

    /**
     * Resolves the text associated with the given preload key.
     *
     * @param key preload text key
     * @return resolved text for the given key
     */
    default String get(PreloadKey key) {return key.defaultText();}
}