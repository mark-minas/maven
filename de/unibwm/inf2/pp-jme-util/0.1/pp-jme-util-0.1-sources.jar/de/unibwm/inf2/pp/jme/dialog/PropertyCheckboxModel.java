//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

import com.simsilica.lemur.CheckboxModel;
import com.simsilica.lemur.core.VersionedReference;
import de.unibwm.inf2.pp.util.BooleanProperty;
import org.checkerframework.dataflow.qual.SideEffectFree;

import java.util.Objects;

/**
 * Lemur {@link CheckboxModel} backed by a persistent {@link BooleanProperty}.
 *
 * <p>
 * This class adapts a preference-backed boolean property to Lemur's
 * checkbox-model interface. State changes are written through immediately to
 * the underlying property, and the property's version counter is exposed as the
 * model version required by Lemur's incremental update mechanism.
 * </p>
 */
public class PropertyCheckboxModel implements CheckboxModel {

    /**
     * Underlying persistent boolean property.
     */
    private final BooleanProperty property;

    /**
     * Creates a new checkbox model backed by the specified property.
     *
     * @param property underlying persistent property; must not be {@code null}
     */
    public PropertyCheckboxModel(BooleanProperty property) {
        this.property = Objects.requireNonNull(property, "property");
    }

    /**
     * Updates the checked state.
     *
     * @param state {@code true} if the checkbox shall be checked, {@code false}
     *              otherwise
     */
    @Override
    public void setChecked(boolean state) {
        property.set(state);
    }

    /**
     * Returns the current checked state.
     *
     * @return {@code true} if checked, {@code false} otherwise
     */
    @Override
    @SideEffectFree
    public boolean isChecked() {
        return property.get();
    }

    /**
     * Returns the current version counter of this model.
     *
     * <p>
     * The returned value is the version of the underlying property and
     * therefore changes whenever the checked state changes.
     * </p>
     *
     * @return the current version counter
     */
    @Override
    @SideEffectFree
    public long getVersion() {
        return property.getVersion();
    }

    /**
     * Returns the current state as a boxed object.
     *
     * @return the current state as {@link Boolean}
     */
    @Override
    @SideEffectFree
    public Boolean getObject() {
        return isChecked();
    }

    /**
     * Creates a {@link VersionedReference} bound to this model.
     *
     * @return a new versioned reference
     */
    @Override
    public VersionedReference<Boolean> createReference() {
        return new VersionedReference<>(this);
    }

    /**
     * Returns a string representation of this checkbox model.
     *
     * @return string representation containing the current checked state
     */
    @Override
    public String toString() {
        return "PropertyCheckboxModel[value=" + isChecked() + "]";
    }
}