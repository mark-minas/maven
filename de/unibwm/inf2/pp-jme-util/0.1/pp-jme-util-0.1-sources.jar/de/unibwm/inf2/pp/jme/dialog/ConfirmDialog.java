//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

import com.simsilica.lemur.Button;
import com.simsilica.lemur.Container;
import com.simsilica.lemur.Label;
import com.simsilica.lemur.component.BorderLayout;
import com.simsilica.lemur.style.ElementId;

import java.util.Objects;

import static com.simsilica.lemur.component.BorderLayout.Position.East;
import static com.simsilica.lemur.component.BorderLayout.Position.West;

/**
 * Modal dialog presenting a confirmation question with explicit affirmative and
 * negative choices.
 *
 * <p>
 * This dialog displays a framework-localized title, a caller-supplied message,
 * and two framework-localized buttons corresponding to confirmation and
 * rejection. It is intended for operations that require explicit user consent,
 * such as terminating a session or discarding unsaved state.
 * </p>
 *
 * <p>
 * The dialog framework localizes only the reusable chrome texts
 * (title, button captions). The concrete dialog message is supplied by the
 * client and is expected to already be appropriate for direct display.
 * </p>
 */
public class ConfirmDialog extends LocalizedDialog {

    /**
     * Message displayed in the dialog body.
     */
    private final String message;

    /**
     * Action executed when the user confirms.
     */
    private final Runnable onConfirm;

    /**
     * Action executed when the user declines.
     */
    private final Runnable onDecline;

    /**
     * Creates a new confirmation dialog.
     *
     * @param message   dialog message shown in the body; must not be {@code null}
     * @param onConfirm action executed when the user confirms; must not be {@code null}
     * @param onDecline action executed when the user declines; must not be {@code null}
     * @param texts     typed dialog texts for framework-owned chrome; must not be
     *                  {@code null}
     */
    public ConfirmDialog(String message,
                         Runnable onConfirm,
                         Runnable onDecline,
                         DialogTextResolver texts) {
        super(texts);
        this.message = Objects.requireNonNull(message, "message");
        this.onConfirm = Objects.requireNonNull(onConfirm, "onConfirm");
        this.onDecline = Objects.requireNonNull(onDecline, "onDecline");
    }

    /**
     * Creates a new confirmation dialog with a no-op decline action.
     *
     * @param message   dialog message shown in the body; must not be {@code null}
     * @param onConfirm action executed when the user confirms; must not be {@code null}
     * @param texts     typed dialog texts for framework-owned chrome; must not be
     *                  {@code null}
     */
    public ConfirmDialog(String message,
                         Runnable onConfirm,
                         DialogTextResolver texts) {
        this(message, onConfirm, () -> {}, texts);
    }

    @Override
    protected void initializeDialog() {
        addChild(new Label(text(DialogKey.CONFIRM_TITLE), new ElementId("header"))); // NON-NLS
        addChild(new Label(message));

        final Container buttons = addChild(new Container(new BorderLayout()));
        final Button yesButton = buttons.addChild(new Button(text(DialogKey.YES)), West);
        final Button noButton = buttons.addChild(new Button(text(DialogKey.NO)), East);

        yesButton.addClickCommands(_ -> {
            close();
            onConfirm.run();
        });

        noButton.addClickCommands(_ -> {
            close();
            onDecline.run();
        });
    }
}