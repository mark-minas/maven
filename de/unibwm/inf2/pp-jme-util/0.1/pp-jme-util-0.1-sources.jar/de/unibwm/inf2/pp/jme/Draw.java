//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme;

import com.jme3.asset.AssetManager;
import com.jme3.material.MatParamOverride;
import com.jme3.material.Material;
import com.jme3.material.RenderState;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Mesh;
import com.jme3.scene.VertexBuffer;
import com.jme3.scene.shape.Quad;
import com.jme3.shader.VarType;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;

import static com.jme3.math.FastMath.FLT_EPSILON;
import static com.jme3.math.FastMath.TWO_PI;
import static com.jme3.math.FastMath.cos;
import static com.jme3.math.FastMath.sin;
import static com.jme3.math.FastMath.sqr;
import static com.jme3.math.FastMath.sqrt;

/**
 * Utility for creating simple reusable geometric primitives for two-dimensional
 * and overlay-oriented rendering.
 *
 * <p>
 * This class provides static factory methods for frequently needed helper
 * geometries such as thin lines, thick lines, rectangles, and ellipses. The
 * implementation internally maintains prototype geometries and returns cloned
 * instances configured according to the requested parameters.
 * </p>
 *
 * <p>
 * The class follows a singleton-style initialization model: the static method
 * {@link #initialize(AssetManager)} must be invoked exactly once before any
 * drawing factory method is used. This allows the utility to create and cache
 * shared material and mesh prototypes bound to a concrete
 * {@link AssetManager}.
 * </p>
 *
 * <h2>Rendering model</h2>
 * <p>
 * All generated geometries use the unshaded material definition
 * {@code Common/MatDefs/Misc/Unshaded.j3md}. Color customization is realized
 * via per-geometry {@link MatParamOverride} instances affecting the material
 * parameter identified by {@link #COLOR}. Alpha blending is enabled and face
 * culling is disabled in order to support overlay-style rendering.
 * </p>
 *
 * <h2>Intended use</h2>
 * <p>
 * The utility is particularly suitable for lightweight debugging aids, HUD
 * overlays, and simple procedural visualizations. It is not intended as a
 * replacement for a full-featured retained-mode vector graphics framework.
 * </p>
 */
public class Draw {
    private static final Logger LOGGER = System.getLogger(Draw.class.getName());

    /**
     * The String used to identify color properties.
     */
    public static final String COLOR = "Color"; //NON-NLS
    private static final int NUM_CIRCLE_SEGMENTS = 10;
    private static final String UNSHADED = "Common/MatDefs/Misc/Unshaded.j3md"; //NON-NLS
    private static final ColorRGBA DEFAULT_COLOR = ColorRGBA.White;
    private final Material material;
    private @MonotonicNonNull Geometry lineInstance;
    private @MonotonicNonNull Geometry rectangleInstance;
    private @MonotonicNonNull Geometry circleInstance;

    private static @MonotonicNonNull Draw instance;

    /**
     * Initializes the singleton instance.
     *
     * @param assetManager asset manager used to create the base material
     * @throws IllegalStateException if called more than once
     */
    public static void initialize(AssetManager assetManager) {
        if (instance != null)
            throw new IllegalStateException("Draw instance has already been initialized");
        instance = new Draw(assetManager);
    }

    /**
     * Returns the initialized singleton.
     *
     * @return draw singleton
     * @throws IllegalStateException if {@link #initialize(AssetManager)} was not called
     */
    private static Draw getInstance() {
        if (instance == null)
            throw new IllegalStateException("Draw instance has not been initialized");
        return instance;
    }

    /**
     * Creates an in stance of the Draw class with the specified
     * asset manager.
     *
     * @param assetManager the asset manager
     */
    private Draw(AssetManager assetManager) {
        this.material = new Material(assetManager, UNSHADED);
        material.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        material.getAdditionalRenderState().setFaceCullMode(RenderState.FaceCullMode.Off);
        material.setColor(COLOR, DEFAULT_COLOR);
    }

    private Geometry makeLine() {
        if (lineInstance != null)
            return lineInstance.clone();
        LOGGER.log(Level.DEBUG, "create line");
        lineInstance = new Geometry("lineMesh", makeLineMesh());
        lineInstance.setMaterial(material.clone());
        return lineInstance;
    }

    private static Mesh makeLineMesh() {
        final Mesh mesh = new Mesh();
        mesh.setMode(Mesh.Mode.Lines);
        mesh.setBuffer(VertexBuffer.Type.Position, 3, new float[]{0, 0, 0, 0, 1, 0});
        mesh.setBuffer(VertexBuffer.Type.Index, 2, new short[]{0, 1});
        return mesh;
    }

    private Geometry makeRectangle() {
        if (rectangleInstance != null)
            return rectangleInstance.clone();
        final Mesh quad = new Quad(1f, 1f);
        rectangleInstance = new Geometry("quad", quad); //NON-NLS
        rectangleInstance.setMaterial(material.clone());
        return rectangleInstance;
    }

    private Geometry makeCircle() {
        if (circleInstance != null)
            return circleInstance.clone();
        circleInstance = new Geometry("circleMesh", makeCircleMesh());
        circleInstance.setMaterial(material.clone());
        return circleInstance;
    }

    private static Mesh makeCircleMesh() {
        final float[] pointBuffer = new float[3 * NUM_CIRCLE_SEGMENTS];
        final short[] indexBuffer = new short[NUM_CIRCLE_SEGMENTS];
        int j = 0;
        for (short i = 0; i < NUM_CIRCLE_SEGMENTS; i++) {
            final float angle = TWO_PI / NUM_CIRCLE_SEGMENTS * i;
            pointBuffer[j++] = 0.5f * cos(angle);
            pointBuffer[j++] = 0.5f * sin(angle);
            pointBuffer[j++] = 0f;
            indexBuffer[i] = i;
        }
        final Mesh mesh = new Mesh();
        mesh.setMode(Mesh.Mode.LineLoop);
        mesh.setBuffer(VertexBuffer.Type.Position, 3, pointBuffer);
        mesh.setBuffer(VertexBuffer.Type.Index, 2, indexBuffer);
        return mesh;
    }

    /**
     * Creates a thin line geometry from {@code p1} to {@code p2}.
     *
     * @param p1    start point in local coordinates
     * @param p2    end point in local coordinates
     * @param z     local Z translation (useful for render ordering)
     * @param color line color (white uses the default material color without override)
     * @return a new geometry instance
     */
    public static Geometry makeLine(Vector2f p1, Vector2f p2, float z, ColorRGBA color) {
        return makeLine(p1.getX(), p1.getY(), p2.getX(), p2.getY(), z, color);
    }

    /**
     * Creates a thin line geometry from {@code (x1,y1)} to {@code (x2,y2)}.
     *
     * <p>
     * The returned geometry is scaled and oriented so that the prototype line mesh
     * (from (0,0,0) to (0,1,0)) spans the requested endpoints.
     * </p>
     *
     * @param x1    x-coordinate of the start point
     * @param y1    y-coordinate of the start point
     * @param x2    x-coordinate of the end point
     * @param y2    y-coordinate of the end point
     * @param z     local Z translation
     * @param color line color
     * @return a new geometry instance
     */
    public static Geometry makeLine(float x1, float y1, float x2, float y2, float z, ColorRGBA color) {
        final Geometry line = getInstance().makeLine();
        line.lookAt(Vector3f.UNIT_Z, new Vector3f(x2 - x1, y2 - y1, 0));
        line.setLocalScale(sqrt(sqr(x2 - x1) + sqr(y2 - y1)));
        line.setLocalTranslation(x1, y1, z);
        overrideColor(line, color);
        return line;
    }

    /**
     * Applies a per-geometry color override if the color differs from {@link #DEFAULT_COLOR}.
     *
     * @param spatial geometry to update
     * @param color   override color
     */
    private static void overrideColor(Geometry spatial, ColorRGBA color) {
        spatial.getLocalMatParamOverrides().removeIf(p -> p.getName().equals(COLOR));
        if (!DEFAULT_COLOR.equals(color))
            spatial.addMatParamOverride(new MatParamOverride(VarType.Vector4, Draw.COLOR, color));
    }

    /**
     * Creates a thick line as a rotated/scaled quad spanning {@code p1} to {@code p2}.
     *
     * @param p1    start point
     * @param p2    end point
     * @param z     local Z translation
     * @param color line color
     * @param width line width in local units
     * @return a new geometry instance
     */
    public static Geometry makeFatLine(Vector2f p1, Vector2f p2, float z, ColorRGBA color, float width) {
        return makeFatLine(p1.getX(), p1.getY(), p2.getX(), p2.getY(), z, color, width);
    }

    /**
     * Creates a thick line as a rotated/scaled quad spanning {@code (x1,y1)} to {@code (x2,y2)}.
     *
     * <p>
     * For extremely short lines (length {@code <= FLT_EPSILON}), the quad is placed as a small square.
     * </p>
     *
     * @param x1    x-coordinate of the start point
     * @param y1    y-coordinate of the start point
     * @param x2    x-coordinate of the end point
     * @param y2    y-coordinate of the end point
     * @param z     local Z translation
     * @param color line color
     * @param width line width in local units
     * @return a new geometry instance
     */
    public static Geometry makeFatLine(float x1, float y1, float x2, float y2, float z, ColorRGBA color, float width) {
        final Geometry line = getInstance().makeRectangle();
        final float dx = x2 - x1;
        final float dy = y2 - y1;
        final float len = sqrt(dx * dx + dy * dy);
        line.setLocalScale(width, len + width, 1f);
        if (len <= FLT_EPSILON)
            line.setLocalTranslation(x1 - 0.5f * width, y1 - 0.5f * width, z);
        else {
            final float f = 0.5f * width / len;
            line.setLocalTranslation(x1 - f * (dy + dx), y1 - f * (dy - dx), z);
            line.getLocalRotation().lookAt(Vector3f.UNIT_Z, new Vector3f(dx, dy, 0f));
        }
        overrideColor(line, color);
        return line;
    }

    /**
     * Creates an axis-aligned rectangle (filled quad) at {@code (x,y)} with size {@code (w,h)}.
     *
     * @param x     x-coordinate of the bottom-left corner
     * @param y     y-coordinate of the bottom-left corner
     * @param z     local Z translation
     * @param w     width in local units
     * @param h     height in local units
     * @param color fill color
     * @return a new geometry instance
     */
    public static Geometry makeRectangle(float x, float y, float z, float w, float h, ColorRGBA color) {
        final Geometry rectangle = getInstance().makeRectangle();
        rectangle.setLocalScale(w, h, 1f);
        rectangle.setLocalTranslation(x, y, z);
        overrideColor(rectangle, color);
        return rectangle;
    }

    /**
     * Creates an ellipse geometry centered at {@code (x,y)} with size {@code (w,h)}.
     *
     * <p>
     * The base mesh is a unit circle line-loop; scaling transforms it into an ellipse.
     * </p>
     *
     * @param x     x-coordinate of the center
     * @param y     y-coordinate of the center
     * @param z     local Z translation
     * @param w     width in local units
     * @param h     height in local units
     * @param color line color
     * @return a new geometry instance
     */
    public static Geometry makeEllipse(float x, float y, float z, float w, float h, ColorRGBA color) {
        final Geometry ellipse = getInstance().makeCircle();
        ellipse.setLocalScale(w, h, 1f);
        ellipse.setLocalTranslation(x, y, z);
        overrideColor(ellipse, color);
        return ellipse;
    }
}