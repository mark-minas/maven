//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme.dialog;

import com.simsilica.lemur.RangedValueModel;
import com.simsilica.lemur.core.VersionedReference;
import de.unibwm.inf2.pp.util.DoubleProperty;
import org.checkerframework.dataflow.qual.SideEffectFree;

import java.util.Objects;

/**
 * Lemur {@link RangedValueModel} backed by a persistent {@link DoubleProperty}.
 *
 * <p>
 * The model stores its value in a preference-backed property and constrains it
 * to a configurable closed interval {@code [minimum, maximum]}. Values written
 * through the model are clamped into that interval.
 * </p>
 *
 * <p>
 * The model maintains an additional local version counter for range changes.
 * The version reported to Lemur is the sum of that local version and the
 * underlying property's version, thereby reflecting both value updates and
 * interval updates.
 * </p>
 */
public class PropertyRangedValueModel implements RangedValueModel {

    /**
     * Underlying persistent value property.
     */
    private final DoubleProperty property;

    /**
     * Local version counter for range changes.
     */
    private long rangeVersion;

    /**
     * Minimum allowed value.
     */
    private double minimum;

    /**
     * Maximum allowed value.
     */
    private double maximum;

    /**
     * Creates a new ranged value model and clamps the current property value
     * into the specified initial range.
     *
     * @param property persistent storage for the value; must not be {@code null}
     * @param minimum  inclusive lower bound
     * @param maximum  inclusive upper bound
     * @throws NullPointerException     if {@code property} is {@code null}
     * @throws IllegalArgumentException if {@code minimum > maximum}
     */
    public PropertyRangedValueModel(DoubleProperty property, double minimum, double maximum) {
        this.property = Objects.requireNonNull(property, "property");
        validateRange(minimum, maximum);
        this.minimum = minimum;
        this.maximum = maximum;
        property.set(Math.clamp(property.get(), minimum, maximum));
    }

    /**
     * Returns the current version counter of this model.
     *
     * @return combined model/property version
     */
    @Override
    @SideEffectFree
    public long getVersion() {
        return rangeVersion + property.getVersion();
    }

    /**
     * Returns the current value as a boxed object.
     *
     * @return the current value as {@link Double}
     */
    @Override
    @SideEffectFree
    public Double getObject() {
        return getValue();
    }

    /**
     * Creates a {@link VersionedReference} bound to this model.
     *
     * @return a new versioned reference
     */
    @Override
    public VersionedReference<Double> createReference() {
        return new VersionedReference<>(this);
    }

    /**
     * Sets the current value after clamping it into the current range.
     *
     * @param value new value
     */
    @Override
    public void setValue(double value) {
        property.set(Math.clamp(value, minimum, maximum));
    }

    /**
     * Returns the current value.
     *
     * @return the current value, guaranteed to lie in the current range
     */
    @Override
    @SideEffectFree
    public double getValue() {
        return property.get();
    }

    /**
     * Sets the range of this model atomically and re-clamps the current value if
     * necessary.
     *
     * @param minimum new inclusive lower bound
     * @param maximum new inclusive upper bound
     * @throws IllegalArgumentException if {@code minimum > maximum}
     */
    public void setRange(double minimum, double maximum) {
        validateRange(minimum, maximum);

        if (Double.compare(this.minimum, minimum) == 0
            && Double.compare(this.maximum, maximum) == 0) {
            return;
        }

        this.minimum = minimum;
        this.maximum = maximum;
        rangeVersion++;
        setValue(getValue());
    }

    /**
     * Sets the current value from a normalized position within the current
     * range.
     *
     * @param percent normalized position in {@code [0.0, 1.0]}
     */
    public void setPercent(double percent) {
        setValue(minimum + (maximum - minimum) * percent);
    }

    /**
     * Returns the current value as a normalized position within the current
     * range.
     *
     * @return normalized position in {@code [0.0, 1.0]}; returns {@code 0.0}
     * if the range is degenerate
     */
    public double getPercent() {
        final double range = maximum - minimum;
        return range == 0d ? 0d : (getValue() - minimum) / range;
    }

    /**
     * Updates the maximum bound and re-clamps the current value if necessary.
     *
     * @param maximum new inclusive upper bound
     * @throws IllegalArgumentException if {@code maximum < minimum}
     */
    @Override
    public void setMaximum(double maximum) {
        setRange(minimum, maximum);
    }

    /**
     * Returns the inclusive upper bound.
     *
     * @return the inclusive upper bound
     */
    @Override
    public double getMaximum() {
        return maximum;
    }

    /**
     * Updates the minimum bound and re-clamps the current value if necessary.
     *
     * @param minimum new inclusive lower bound
     * @throws IllegalArgumentException if {@code minimum > maximum}
     */
    @Override
    public void setMinimum(double minimum) {
        setRange(minimum, maximum);
    }

    /**
     * Returns the inclusive lower bound.
     *
     * @return the inclusive lower bound
     */
    @Override
    public double getMinimum() {
        return minimum;
    }

    @Override
    public String toString() {
        return "PropertyRangedValueModel[value=" + getValue()
               + ", minimum=" + minimum
               + ", maximum=" + maximum + "]";
    }

    /**
     * Validates the specified range.
     *
     * @param minimum proposed lower bound
     * @param maximum proposed upper bound
     * @throws IllegalArgumentException if {@code minimum > maximum}
     */
    private static void validateRange(double minimum, double maximum) {
        if (minimum > maximum) {
            throw new IllegalArgumentException("minimum must not exceed maximum");
        }
    }
}