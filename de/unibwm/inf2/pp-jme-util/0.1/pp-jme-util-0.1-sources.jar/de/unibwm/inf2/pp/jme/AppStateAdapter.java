//----------------------------------------
// Programming project code
// UniBw M, 2022-2025
// www.unibw.de/inf2
// (c) Mark Minas (mark.minas@unibw.de)
//----------------------------------------

package de.unibwm.inf2.pp.jme;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

/**
 * Convenience adapter class for jME app states with empty lifecycle methods.
 *
 * <p>
 * jMonkeyEngine's {@link BaseAppState} defines four lifecycle hooks:
 * initialization, cleanup, enable, and disable. In many concrete states, only
 * a subset of these hooks is needed. This adapter provides no-op
 * implementations for all four methods so that subclasses may override only the
 * operations that are semantically relevant to them.
 * </p>
 *
 * <p>
 * The class therefore serves the same purpose as a classical adapter in event-
 * or callback-oriented APIs: it reduces boilerplate while preserving the full
 * structural contract of the underlying base type.
 * </p>
 */
public class AppStateAdapter extends BaseAppState {
    /**
     * Creates an adapter with an automatically assigned state ID.
     */
    public AppStateAdapter() {
        super();
    }

    /**
     * Creates an adapter with a custom identifier.
     *
     * @param id human-readable state ID (useful for debugging and lookups)
     */
    public AppStateAdapter(String id) {
        super(id);
    }

    @Override
    protected void initialize(Application app) { /* empty */ }

    @Override
    protected void cleanup(Application app) { /* empty */ }

    @Override
    protected void onEnable() { /* empty */ }

    @Override
    protected void onDisable() { /* empty */ }
}